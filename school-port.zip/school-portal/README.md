# High School Portal — Project Documentation

Secure, mobile-first, multi-persona portal for **Admin · Teacher · Student · Parent**.

## Documentation index

| Phase | Document | Status |
| --- | --- | --- |
| 1 | [Architecture & Tech Stack](docs/phase-1-architecture.md) | **Approved 2026-10-01** (decisions in ADR-009/010) |
| 1 | [System architecture diagram (SVG)](docs/diagrams/system-architecture.svg) | Approved |
| 1 | [Architecture Decision Records](docs/adr/phase-1-decisions.md) | ADR-001…012 |
| 2 | [Database schema & ER model](docs/phase-2-database-schema.md) | **Approved 2026-10-01** |
| 2 | [ER diagram (SVG)](docs/diagrams/er-diagram.svg) | Approved |
| 3 | [API design (REST/OpenAPI + WebSocket + webhooks)](docs/phase-3-api-design.md) | **Approved 2026-10-01** |
| 4 | [Frontend component tree & state strategy](docs/phase-4-frontend-design.md) | **Approved 2026-10-01** |
| 5 | [Implementation log](docs/phase-5-implementation.md) (auth + DB + web + notifications/messaging/SSO + fees/exams/transport, tested) | **Complete 2026-10-01 — steps 5.1–5.4 done (34 API tests, 43 web checks)** |

## Phase 1 at a glance

- **Frontend:** Next.js 16 (App Router) · React 19.2 · TypeScript strict · Tailwind v4 + shadcn/ui · TanStack Query · Serwist PWA with offline attendance
- **API:** NestJS 12 modular monolith · REST + OpenAPI 3.1 · Socket.IO gateway · BullMQ workers
- **Data:** PostgreSQL 18 + Row-Level Security · Redis 7 (sessions, cache, queues) · S3/R2 for files · read replica
- **Identity:** Microsoft Entra ID / Google Workspace via OIDC + PKCE · local email+passkey for parents · MFA (TOTP/WebAuthn) enforced for staff
- **Security:** BFF httpOnly session cookies · TLS 1.3 · AES-256-GCM envelope encryption on PII columns with HMAC blind indexes · append-only audit log
- **Compliance:** FERPA · COPPA under-13 gate · WCAG 2.2 AA · Nigeria NDPA 2023 + GAID 2025 where applicable

## Decisions received (2026-10-01) — locked for v1

1. Single school · 2. Both Entra **and** Google Workspace · 3. eu-west-1, Managed PaaS · 4. Parents read-only · 5. Fees/exams/transport **in** v1.
Full consequences: [`docs/adr/phase-1-decisions.md`](docs/adr/phase-1-decisions.md) (ADR-009, ADR-010).
