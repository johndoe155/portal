import {
  Body, ConflictException, Controller, Get, Headers, Inject, NotFoundException, Param, Post, Req,
  ServiceUnavailableException, UnauthorizedException, UnprocessableEntityException,
} from "@nestjs/common";
import { createHmac, randomUUID, timingSafeEqual } from "node:crypto";
import { and, eq, isNull, sql } from "drizzle-orm";
import type { Db } from "../db/client";
import { DB_TOKEN } from "../db/token";
import { withActor, SERVICE } from "../db/actor";
import { feeInvoices, feePayments, guardians, students } from "../db/schema";
import { Perm } from "../common/guards";
import { insertAudit } from "../common/audit";
import { config } from "../config";
import { InvoiceCreateBody, PaymentRecordBody } from "@portal/contracts";
import type { Request } from "express";

const LEDGER_ROLES = new Set(["super_admin", "school_admin"]);

/** Fees: invoices + payments (kobo). Paystack webhook is public + HMAC-verified. */
@Controller()
export class FeesController {
  constructor(@Inject(DB_TOKEN) private db: Db) {}

  /** admin ledger */
  @Get("fees/invoices")
  @Perm("fees:read")
  async listInvoices(@Req() req: Request) {
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const rows = await tx.select().from(feeInvoices).limit(200);
      return { data: rows };
    });
  }

  /** student's own ledger */
  @Get("fees/my")
  @Perm("self:read")
  async myFees(@Req() req: Request) {
    const p = req.principal!;
    return this.ledgerFor(p.userId, p);
  }

  /** guardian: child's ledger */
  @Get("parent/children/:id/fees")
  @Perm("family:read")
  async childFees(@Req() req: Request, @Param("id") id: string) {
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      await this.assertGuardian(tx, p.userId, id);
    }).then(() => this.ledgerFor(id, p));
  }

  @Post("fees/invoices")
  @Perm("fees:write")
  async createInvoice(@Req() req: Request, @Body() body: unknown) {
    const parsed = InvoiceCreateBody.safeParse(body);
    if (!parsed.success) {
      throw new UnprocessableEntityException({ code: "validation", detail: parsed.error.message });
    }
    const p = req.principal!;
    const b = parsed.data;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const [student] = await tx.select({ userId: students.userId }).from(students)
        .where(eq(students.userId, b.student_user_id)).limit(1);
      if (!student) throw new UnprocessableEntityException({ code: "not_a_student" });
      const [dupe] = await tx.select({ id: feeInvoices.id }).from(feeInvoices)
        .where(and(eq(feeInvoices.studentUserId, b.student_user_id), eq(feeInvoices.termId, b.term_id),
          eq(feeInvoices.label, b.label))).limit(1);
      if (dupe) throw new ConflictException({ code: "invoice_exists" });
      const [inv] = await tx.insert(feeInvoices).values({
        id: randomUUID(), studentUserId: b.student_user_id, termId: b.term_id, label: b.label,
        amountKobo: b.amount_kobo, dueDate: b.due_date ?? null,
      }).returning();
      await insertAudit(tx, { actorUserId: p.userId, action: "invoice.created",
        entityType: "fee_invoice", entityId: inv.id, after: { kobo: b.amount_kobo }, ip: req.ip });
      return inv;
    });
  }

  /** create a pending payment + reference (prod: calls Paystack Initialize Transaction) */
  @Post("fees/invoices/:id/initiate")
  @Perm("fees:write")
  async initiate(@Req() req: Request, @Param("id") id: string) {
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const [inv] = await tx.select().from(feeInvoices).where(eq(feeInvoices.id, id)).limit(1);
      if (!inv) throw new NotFoundException({ code: "not_found" });
      if (inv.status === "paid" || inv.status === "void") {
        throw new ConflictException({ code: "invoice_not_payable" });
      }
      const reference = `psk_${randomUUID()}`;
      const [pay] = await tx.insert(feePayments).values({
        id: randomUUID(), invoiceId: id, amountKobo: inv.amountKobo,
        channel: "paystack", gatewayRef: reference, paidBy: p.userId,
      }).returning();
      await insertAudit(tx, { actorUserId: p.userId, action: "payment.initiated",
        entityType: "fee_payment", entityId: pay.id, after: { reference } });
      // production: POST https://api.paystack.co/transaction/initialize then return auth_url
      return { reference, amount_kobo: inv.amountKobo, checkout_url: null,
        note: "Paystack Initialize call is the production path; webhook completes the loop" };
    });
  }

  /** record an offline payment (cash/transfer) — completes immediately */
  @Post("fees/invoices/:id/payments")
  @Perm("fees:write")
  async recordPayment(@Req() req: Request, @Param("id") id: string, @Body() body: unknown) {
    const parsed = PaymentRecordBody.safeParse(body);
    if (!parsed.success) {
      throw new UnprocessableEntityException({ code: "validation", detail: parsed.error.message });
    }
    const p = req.principal!;
    const b = parsed.data;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const [inv] = await tx.select().from(feeInvoices).where(eq(feeInvoices.id, id)).limit(1);
      if (!inv) throw new NotFoundException({ code: "not_found" });
      if (inv.status === "paid" || inv.status === "void") {
        throw new ConflictException({ code: "invoice_not_payable" });
      }
      const [pay] = await tx.insert(feePayments).values({
        id: randomUUID(), invoiceId: id, amountKobo: b.amount_kobo, channel: b.channel,
        status: "success", paidBy: p.userId, paidAt: new Date(),
      }).returning();
      await this.recomputeInvoice(tx, id, p.userId, "payment.recorded", req.ip);
      return pay;
    });
  }

  /**
   * Paystack webhook — public route, HMAC SHA-512 over the RAW body
   * (x-paystack-signature). Idempotent via the unique gateway_ref.
   */
  @Post("webhooks/paystack")
  async paystackWebhook(@Req() req: Request,
                        @Headers("x-paystack-signature") signature?: string) {
    const secret = config.paystackSecret;
    if (!secret) {
      throw new ServiceUnavailableException({ code: "webhook_not_configured",
        detail: "PAYSTACK_SECRET is not set" });
    }
    const raw = (req as any).rawBody as Buffer | undefined;
    if (!raw || !signature) {
      throw new UnauthorizedException({ code: "webhook_unverified" });
    }
    const expect = createHmac("sha512", secret).update(raw).digest("hex");
    const got = Buffer.from(signature);
    const want = Buffer.from(expect);
    if (got.length !== want.length || !timingSafeEqual(got, want)) {
      throw new UnauthorizedException({ code: "webhook_unverified" });
    }
    let event: any;
    try { event = JSON.parse(raw.toString()); } catch { event = null; }
    if (!event || event.event !== "charge.success") return { ignored: true };

    const reference = event?.data?.reference as string | undefined;
    const amountKobo = Number(event?.data?.amount ?? 0);
    if (!reference) return { ignored: true };

    return withActor(this.db, SERVICE, async (tx) => {
      const [pay] = await tx.select().from(feePayments)
        .where(eq(feePayments.gatewayRef, reference)).limit(1);
      if (!pay) {
        await insertAudit(tx, { actorUserId: null, action: "webhook.orphan",
          entityType: "fee_payment", after: { reference } });
        return { ignored: true, reason: "unknown_reference" };
      }
      if (pay.status === "success") return { duplicate: true };
      await tx.update(feePayments)
        .set({ status: "success", paidAt: new Date(),
          amountKobo: amountKobo > 0 ? amountKobo : pay.amountKobo })
        .where(eq(feePayments.id, pay.id));
      await this.recomputeInvoice(tx, pay.invoiceId, null, "webhook.charge_success");
      return { applied: true, payment_id: pay.id };
    });
  }

  private async ledgerFor(studentUserId: string, p: { userId: string; activeRole: string }) {
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const invoices = await tx.select().from(feeInvoices)
        .where(eq(feeInvoices.studentUserId, studentUserId));
      const ids = invoices.map((i) => i.id);
      const payments = ids.length
        ? await tx.select().from(feePayments)
            .where(sql`${feePayments.invoiceId} IN (${sql.join(ids, sql`, `)})`)
        : [];
      return { data: { invoices, payments: payments.filter((x) => x.status !== "failed") } };
    });
  }

  /** sum successful payments → invoice status; audit every transition */
  private async recomputeInvoice(tx: Db, invoiceId: string, actorId: string | null,
                                 action: string, ip?: string) {
    const [inv] = await tx.select().from(feeInvoices).where(eq(feeInvoices.id, invoiceId)).limit(1);
    if (!inv) return;
    const rows = await tx.select({ total: sql<number>`COALESCE(SUM(amount_kobo),0)::bigint` })
      .from(feePayments)
      .where(and(eq(feePayments.invoiceId, invoiceId), eq(feePayments.status, "success")));
    const paid = Number(rows[0]?.total ?? 0);
    const status = paid >= Number(inv.amountKobo) ? "paid" : paid > 0 ? "partial" : "due";
    if (status !== inv.status) {
      await tx.update(feeInvoices).set({ status }).where(eq(feeInvoices.id, invoiceId));
    }
    await insertAudit(tx, { actorUserId: actorId, action, entityType: "fee_invoice",
      entityId: invoiceId, after: { paid_kobo: paid, status }, ip });
  }

  private async assertGuardian(tx: Db, userId: string, studentId: string) {
    const [g] = await tx.select({ id: guardians.id }).from(guardians)
      .where(and(eq(guardians.userId, userId), eq(guardians.studentUserId, studentId),
        sql`${guardians.verifiedAt} IS NOT NULL`, isNull(guardians.endedAt))).limit(1);
    if (!g) throw new NotFoundException({ code: "not_found" });
  }
}
