/**
 * Standalone notification worker (Phase 5.3).
 *
 * Dev: point PGLITE_DATA_DIR at the same data dir the API used, with the API
 * stopped (PGlite is single-process). Production: this entry swaps to the
 * node-postgres driver against Neon/Supabase — processQueue/runDigest code is
 * driver-agnostic (drizzle).
 */
import { createDb } from "../db/client";
import { runMigrations } from "../db/migrate";
import { startWorker } from "../notify/notify.service";

async function main() {
  const dataDir = process.env.PGLITE_DATA_DIR; // undefined = in-memory (useless, warns)
  if (!dataDir) console.warn("[worker] no PGLITE_DATA_DIR — running against an empty in-memory DB");
  const made = createDb(dataDir);
  await runMigrations(made.pg);
  const intervalMs = Number(process.env.WORKER_INTERVAL_MS ?? 5000);
  console.log(`[worker] started (interval ${intervalMs}ms, dataDir=${dataDir ?? "<memory>"})`);
  startWorker(made.db, {
    intervalMs,
    pushSinkFile: process.env.PUSH_SINK_FILE ?? "data/push-outbox.jsonl",
    vapid: process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY
      ? { publicKey: process.env.VAPID_PUBLIC_KEY, privateKey: process.env.VAPID_PRIVATE_KEY,
          subject: process.env.VAPID_SUBJECT ?? "mailto:portal@school.example" }
      : undefined,
  });
}

main().catch((err) => { console.error(err); process.exit(1); });
