import { BadRequestException } from "@nestjs/common";
import type { Request } from "express";

/** Idempotency-Key required on risky writes (Phase 3 §1.4). Single-node replay cache for dev. */
const replay = new Map<string, { at: number; body: unknown }>();
const TTL = 24 * 60 * 60 * 1000;

export function requireIdempotencyKey(req: Request): string {
  const key = req.headers["idempotency-key"];
  if (typeof key !== "string" || key.length < 8) {
    throw new BadRequestException({ code: "idempotency_key_required",
      detail: "Idempotency-Key header (>=8 chars) required on this endpoint" });
  }
  return key;
}

export function replayHit(key: string): unknown | undefined {
  const e = replay.get(key);
  if (e && Date.now() - e.at < TTL) return e.body;
  return undefined;
}
export function replayStore(key: string, body: unknown): void {
  if (replay.size > 5000) replay.clear();
  replay.set(key, { at: Date.now(), body });
}
