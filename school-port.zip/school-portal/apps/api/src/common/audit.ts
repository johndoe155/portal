import { createHash, randomUUID } from "node:crypto";
import type { Db } from "../db/client";
import { auditLog } from "../db/schema";

export interface AuditInput {
  actorUserId: string | null;
  action: string;
  entityType?: string;
  entityId?: string;
  before?: unknown;
  after?: unknown;
  ip?: string;
  userAgent?: string;
}

export async function insertAudit(tx: Db, input: AuditInput): Promise<void> {
  const occurredAt = new Date();
  const payload = JSON.stringify([input.actorUserId, input.action, input.entityType,
    input.entityId, input.before ?? null, input.after ?? null, occurredAt.toISOString()]);
  const rowHash = createHash("sha256").update(payload).update(randomUUID()).digest("hex");
  await tx.insert(auditLog).values({
    id: randomUUID(),
    actorUserId: input.actorUserId,
    action: input.action,
    entityType: input.entityType ?? null,
    entityId: input.entityId ?? null,
    beforeJson: (input.before ?? null) as never,
    afterJson: (input.after ?? null) as never,
    ip: input.ip ?? null,
    userAgent: input.userAgent ?? null,
    occurredAt,
    rowHash,
  });
}
