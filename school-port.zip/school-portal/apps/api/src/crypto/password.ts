import { scrypt, randomBytes, timingSafeEqual } from "node:crypto";

const N = 32768;

function scryptAsync(pw: string, salt: Buffer, len: number, n: number): Promise<Buffer> {
  return new Promise((resolve, reject) =>
    scrypt(pw, salt, len, { N: n, maxmem: 128 * n * 8 * 2 }, (err, derived) => err ? reject(err) : resolve(derived as Buffer)));
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const buf = await scryptAsync(password, salt, 64, N);
  return `scrypt$${N}$${salt.toString("base64")}$${buf.toString("base64")}`;
}

export async function verifyPassword(password: string, stored: string | null): Promise<boolean> {
  if (!stored) return false;
  const [alg, nStr, saltB64, hashB64] = stored.split("$");
  if (alg !== "scrypt") return false;
  const salt = Buffer.from(saltB64, "base64");
  const expected = Buffer.from(hashB64, "base64");
  const actual = await scryptAsync(password, salt, expected.length, Number(nStr));
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
