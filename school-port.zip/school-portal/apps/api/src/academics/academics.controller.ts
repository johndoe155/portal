import {
  Body, ConflictException, Controller, Get, Inject, NotFoundException, Param, Post, Req, Query,
  UnprocessableEntityException,
} from "@nestjs/common";
import { randomUUID } from "node:crypto";
import { eq, and } from "drizzle-orm";
import type { Db } from "../db/client";
import { DB_TOKEN } from "../db/token";
import { withActor } from "../db/actor";
import { courseSections, courses, sectionStaff, enrollments, students, users, terms } from "../db/schema";
import { Perm } from "../common/guards";
import { insertAudit } from "../common/audit";
import { SectionCreateBody, EnrollBody } from "@portal/contracts";
import type { Request } from "express";

@Controller()
export class AcademicsController {
  constructor(@Inject(DB_TOKEN) private db: Db) {}

  /** teachers see their sections (RLS), admins see all. */
  @Get("sections")
  @Perm("academics:read")
  async sections(@Req() req: Request, @Query("term") term?: string) {
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const rows = await tx.select({
        id: courseSections.id, name: courseSections.name, status: courseSections.status,
        courseCode: courses.code, courseTitle: courses.title, termId: courseSections.termId,
      }).from(courseSections).innerJoin(courses, eq(courses.id, courseSections.courseId))
        .where(term ? eq(courseSections.termId, term) : undefined);
      return { data: rows };
    });
  }

  @Get("sections/:id/roster")
  @Perm("academics:read")
  async roster(@Req() req: Request, @Param("id") id: string) {
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const [section] = await tx.select().from(courseSections).where(eq(courseSections.id, id)).limit(1);
      if (!section) throw new NotFoundException({ code: "not_found" });
      const rows = await tx.select({
        studentUserId: students.userId, admissionNo: students.admissionNo,
        gradeLevel: students.gradeLevel, displayName: users.displayName,
        status: enrollments.status,
      }).from(enrollments)
        .innerJoin(students, eq(students.userId, enrollments.studentUserId))
        .innerJoin(users, eq(users.id, students.userId))
        .where(and(eq(enrollments.sectionId, id), eq(enrollments.status, "enrolled")));
      return { data: rows };
    });
  }

  /** Phase 5.3: registrar/admin creates a section (course upserted by code) */
  @Post("sections")
  @Perm("academics:write")
  async createSection(@Req() req: Request, @Body() body: unknown) {
    const parsed = SectionCreateBody.safeParse(body);
    if (!parsed.success) {
      throw new UnprocessableEntityException({ code: "validation", detail: parsed.error.message });
    }
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const b = parsed.data;
      let [course] = await tx.select().from(courses)
        .where(eq(courses.code, b.course_code.toUpperCase())).limit(1);
      if (!course) {
        [course] = await tx.insert(courses)
          .values({ id: randomUUID(), code: b.course_code.toUpperCase(), title: b.course_title })
          .returning();
      }
      const [dupe] = await tx.select({ id: courseSections.id }).from(courseSections)
        .where(and(eq(courseSections.courseId, course.id), eq(courseSections.termId, b.term_id),
          eq(courseSections.name, b.name))).limit(1);
      if (dupe) throw new ConflictException({ code: "section_exists" });
      const [section] = await tx.insert(courseSections).values({
        id: randomUUID(), courseId: course.id, termId: b.term_id, name: b.name,
      }).returning();
      await insertAudit(tx, { actorUserId: p.userId, action: "section.created",
        entityType: "course_section", entityId: section.id, ip: req.ip });
      return section;
    });
  }

  /** Phase 5.3: registrar/admin enrolls a student into a section */
  @Post("sections/:id/enrollments")
  @Perm("academics:write")
  async enroll(@Req() req: Request, @Param("id") id: string, @Body() body: unknown) {
    const parsed = EnrollBody.safeParse(body);
    if (!parsed.success) {
      throw new UnprocessableEntityException({ code: "validation", detail: parsed.error.message });
    }
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const [section] = await tx.select({ id: courseSections.id }).from(courseSections)
        .where(eq(courseSections.id, id)).limit(1);
      if (!section) throw new NotFoundException({ code: "not_found" });
      const [student] = await tx.select({ userId: students.userId }).from(students)
        .where(eq(students.userId, parsed.data.student_user_id)).limit(1);
      if (!student) throw new UnprocessableEntityException({ code: "not_a_student" });
      const [existing] = await tx.select({ id: enrollments.id, status: enrollments.status })
        .from(enrollments).where(and(eq(enrollments.sectionId, id),
          eq(enrollments.studentUserId, parsed.data.student_user_id))).limit(1);
      if (existing && existing.status === "enrolled") {
        throw new ConflictException({ code: "already_enrolled" });
      }
      const [row] = await tx.insert(enrollments).values({
        id: randomUUID(), sectionId: id, studentUserId: parsed.data.student_user_id, status: "enrolled",
      }).returning();
      await insertAudit(tx, { actorUserId: p.userId, action: "enrollment.created",
        entityType: "course_section", entityId: id,
        after: { student: parsed.data.student_user_id }, ip: req.ip });
      return row;
    });
  }

  /** terms list (reference data — readable by any authenticated actor) */
  @Get("terms")
  async listTerms(@Req() req: Request) {
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const rows = await tx.select().from(terms);
      return { data: rows };
    });
  }
}
