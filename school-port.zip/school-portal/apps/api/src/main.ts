import "reflect-metadata";
import { config } from "./config";
import { createDb } from "./db/client";
import { runMigrations } from "./db/migrate";
import { seed } from "./seed";
import { createApp } from "./app.factory";

async function bootstrap() {
  const { pg, db } = createDb();
  const applied = await runMigrations(pg);
  await seed(db);
  const app = await createApp(db);
  await app.listen(config.port, "0.0.0.0");
  console.log(`[api] listening on :${config.port} (migrations: ${applied.join(", ")})`);
}
bootstrap().catch((err) => { console.error(err); process.exit(1); });
