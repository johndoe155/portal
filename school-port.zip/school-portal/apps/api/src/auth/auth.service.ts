import { Inject, Injectable, UnauthorizedException, ForbiddenException } from "@nestjs/common";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import { and, eq, isNull, sql } from "drizzle-orm";
import { config } from "../config";
import type { Db } from "../db/client";
import { DB_TOKEN } from "../db/token";
import { withActor, SERVICE } from "../db/actor";
import { users, sessions, mfaFactors, userRoles, rolePermissions, identities } from "../db/schema";
import { hashPassword, verifyPassword } from "../crypto/password";
import { newTotpSecret, verifyTotp } from "../crypto/totp";
import { encryptText, decryptText } from "../crypto/enc";
import { insertAudit } from "../common/audit";
import { defaultActiveRole } from "../common/session.middleware";
import type { Principal } from "../common/principal";

export const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

@Injectable()
export class AuthService {
  constructor(@Inject(DB_TOKEN) private db: Db) {}

  async login(email: string, password: string, meta: { ip?: string; ua?: string }) {
    return withActor(this.db, SERVICE, async (tx) => {
      const [user] = await tx.select().from(users)
        .where(eq(sql`lower(${users.email})`, email.toLowerCase())).limit(1);
      const ok = user && user.status === "active" && await verifyPassword(password, user.passwordHash);
      if (!user || !ok) {
        throw new UnauthorizedException({ code: "invalid_credentials", title: "Invalid credentials" });
      }
      const roleRows = await tx.select().from(userRoles)
        .where(and(eq(userRoles.userId, user.id), isNull(userRoles.revokedAt)));
      const roles = roleRows.map((r) => r.roleCode);
      if (roles.length === 0) {
        throw new UnauthorizedException({ code: "invalid_credentials", title: "Invalid credentials" });
      }
      const token = randomBytes(32).toString("base64url");
      const activeRole = defaultActiveRole(roles);
      await tx.insert(sessions).values({
        id: randomUUID(), userId: user.id,
        tokenHash: createHash("sha256").update(token).digest("hex"),
        activeRole, amr: JSON.stringify(["pwd"]),
        expiresAt: new Date(Date.now() + SESSION_TTL_MS),
        ip: meta.ip ?? null, userAgent: meta.ua ?? null,
      });
      await insertAudit(tx, { actorUserId: user.id, action: "auth.login", entityType: "session",
        ip: meta.ip, userAgent: meta.ua });
      return { token, userId: user.id, roles, activeRole,
        mfaRequired: true, mfaVerified: false };
    });
  }

  async totpEnroll(p: Principal) {
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const secret = newTotpSecret();
      await tx.insert(mfaFactors).values({
        id: randomUUID(), userId: p.userId, kind: "totp",
        label: `totp-${Date.now()}`, secretEnc: encryptText(secret),
      });
      const otpauth = `otpauth://totp/Portal:${encodeURIComponent(p.email)}?secret=${secret}&issuer=Portal`;
      return { secret, otpauthUrl: otpauth };
    });
  }

  async totpVerify(p: Principal, code: string, meta: { ip?: string; ua?: string }) {
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const factors = await tx.select().from(mfaFactors)
        .where(and(eq(mfaFactors.userId, p.userId), eq(mfaFactors.kind, "totp")));
      let matched: string | null = null;
      for (const f of factors) {
        if (verifyTotp(decryptText(f.secretEnc), code)) { matched = f.id; break; }
      }
      if (!matched) {
        throw new UnauthorizedException({ code: "totp_invalid", title: "Invalid code" });
      }
      await tx.update(mfaFactors).set({ lastUsedAt: new Date() }).where(eq(mfaFactors.id, matched));
      await tx.update(sessions).set({ mfaVerifiedAt: new Date() })
        .where(eq(sessions.id, p.sessionId));
      await insertAudit(tx, { actorUserId: p.userId, action: "mfa.verified", entityType: "mfa_factor",
        entityId: matched, ip: meta.ip, userAgent: meta.ua });
      return { mfaVerified: true };
    });
  }

  async logout(p: Principal) {
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      await tx.update(sessions).set({ revokedAt: new Date() }).where(eq(sessions.id, p.sessionId));
      await insertAudit(tx, { actorUserId: p.userId, action: "auth.logout" });
      return { ok: true };
    });
  }

  async switchRole(p: Principal, role: string) {
    if (!p.roles.includes(role)) {
      throw new ForbiddenException({ code: "role_not_held", detail: `you do not hold ${role}` });
    }
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      await tx.update(sessions).set({ activeRole: role }).where(eq(sessions.id, p.sessionId));
      const perms = await tx.select().from(rolePermissions).where(eq(rolePermissions.roleCode, role));
      await insertAudit(tx, { actorUserId: p.userId, action: "auth.role_switch", after: { role } });
      return { activeRole: role, permissions: perms.map((r) => r.permission) };
    });
  }

  /** used by seed & tests */
  static hashPassword = hashPassword;

  /**
   * Phase 5.3 — SSO (OIDC authorization-code).
   * The id_token was signature-verified by sso.service BEFORE this call.
   * Identity link → user resolution (link-by-email or JIT) → session issuance.
   * Runs as SERVICE because identities_* policies are service-only.
   */
  async ssoLogin(provider: string, claims: { sub: string; email: string; name?: string },
                 jitRole: string | undefined, meta: { ip?: string; ua?: string }) {
    return withActor(this.db, SERVICE, async (tx) => {
      let userId: string | null = null;
      const [ident] = await tx.select().from(identities)
        .where(and(eq(identities.provider, provider), eq(identities.subject, claims.sub))).limit(1);
      if (ident) {
        userId = ident.userId;
        await tx.update(identities).set({ lastSeenAt: new Date(), emailSnapshot: claims.email })
          .where(and(eq(identities.provider, provider), eq(identities.subject, claims.sub)));
      } else {
        const [byEmail] = await tx.select().from(users)
          .where(eq(sql`lower(${users.email})`, claims.email.toLowerCase())).limit(1);
        if (byEmail) {
          userId = byEmail.id; // directory user already exists → link the federated identity
        } else if (jitRole) {
          const [created] = await tx.insert(users).values({
            email: claims.email, displayName: claims.name ?? claims.email.split("@")[0],
          }).returning();
          userId = created.id;
          await tx.insert(userRoles).values({ id: randomUUID(), userId, roleCode: jitRole });
        }
        if (!userId) {
          throw new ForbiddenException({ code: "sso_user_not_provisioned",
            title: "No portal account is linked to this identity",
            detail: "Ask your administrator to create your account first" });
        }
        await tx.insert(identities).values({
          userId, provider, subject: claims.sub, emailSnapshot: claims.email, lastSeenAt: new Date(),
        });
      }
      const [user] = await tx.select().from(users).where(eq(users.id, userId)).limit(1);
      if (!user || user.status !== "active") {
        throw new UnauthorizedException({ code: "account_inactive", title: "Account is not active" });
      }
      const roleRows = await tx.select().from(userRoles)
        .where(and(eq(userRoles.userId, user.id), isNull(userRoles.revokedAt)));
      const roles = roleRows.map((r) => r.roleCode);
      if (roles.length === 0) {
        throw new ForbiddenException({ code: "no_roles", title: "Account has no portal role" });
      }
      const token = randomBytes(32).toString("base64url");
      await tx.insert(sessions).values({
        id: randomUUID(), userId: user.id,
        tokenHash: createHash("sha256").update(token).digest("hex"),
        activeRole: defaultActiveRole(roles), amr: JSON.stringify([`sso:${provider}`]),
        expiresAt: new Date(Date.now() + SESSION_TTL_MS),
        ip: meta.ip ?? null, userAgent: meta.ua ?? null,
      });
      await insertAudit(tx, { actorUserId: user.id, action: "auth.sso_login", entityType: "session",
        after: { provider, sub: claims.sub }, ip: meta.ip, userAgent: meta.ua });
      return { token, userId: user.id, email: user.email, roles,
        activeRole: defaultActiveRole(roles) };
    });
  }
}
