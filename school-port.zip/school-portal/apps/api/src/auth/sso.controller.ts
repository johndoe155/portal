import { BadRequestException, Controller, Get, Param, Query, Req, Res, ForbiddenException } from "@nestjs/common";
import { randomBytes } from "node:crypto";
import type { Request, Response } from "express";
import { config } from "../config";
import { AuthService } from "./auth.service";
import {
  authorizeUrl, claimsOf, exchangeCode, getProvider, signState, verifyIdToken, verifyState,
} from "./sso.service";
import { STAFF_ROLES } from "../common/principal";

/**
 * OIDC authorization-code flow (Entra ID + Google Workspace, Phase-1 §4).
 * Public routes — the session middleware whitelists /api/v1/auth/sso/*.
 * The callback sets the session cookie on the WEB origin because the browser
 * arrives via the BFF rewrite (ADR-012); redirect_uri points there too.
 */
@Controller("auth/sso")
export class SsoController {
  constructor(private auth: AuthService) {}

  @Get(":provider/start")
  start(@Param("provider") provider: string, @Res() res: Response) {
    let p;
    try { p = getProvider(provider); }
    catch (e: any) {
      if (e?.code === "sso_not_configured") {
        throw new BadRequestException({ code: "sso_not_configured", detail: e.message });
      }
      throw e;
    }
    res.redirect(302, authorizeUrl(p, signState(provider)));
  }

  @Get(":provider/callback")
  async callback(@Param("provider") provider: string,
                 @Query("code") code: string, @Query("state") state: string,
                 @Req() req: Request, @Res() res: Response) {
    const fail = (detail: string) =>
      res.redirect(302, `${config.publicWebOrigin}/login?sso_error=${encodeURIComponent(detail)}`);
    let p;
    try { p = getProvider(provider); } catch { return fail("provider not configured"); }
    if (!code || !state) return fail("missing code or state");
    try { verifyState(state, provider); } catch (e: any) { return fail(`state: ${e.message}`); }
    try {
      const idToken = await exchangeCode(p, code);
      const payload = await verifyIdToken(p, idToken);
      const claims = claimsOf(payload as any);
      const out = await this.auth.ssoLogin(provider, claims, p.jitRole,
        { ip: req.ip, ua: req.headers["user-agent"] });
      res.cookie(config.sidCookie, out.token, {
        httpOnly: true, sameSite: "strict", secure: config.cookieSecure,
        path: "/", maxAge: 12 * 60 * 60 * 1000,
      });
      if (!req.cookies?.[config.csrfCookie]) {
        res.cookie(config.csrfCookie, randomBytes(16).toString("base64url"), {
          httpOnly: false, sameSite: "strict", secure: config.cookieSecure, path: "/",
        });
      }
      // staff still face the MFA gate after SSO (web redirects on session.mfaRequired)
      const needsMfa = out.roles.some((r) => STAFF_ROLES.has(r));
      res.redirect(302, `${config.publicWebOrigin}${needsMfa ? "/mfa" : "/"}`);
    } catch (e: any) {
      const code = e?.response?.code ?? e?.message ?? "sso_failed";
      if (e?.status === 403 || code === "sso_user_not_provisioned") {
        return res.status(403).json({ code: "sso_user_not_provisioned",
          title: "No portal account is linked to this identity" });
      }
      return fail(String(code).slice(0, 120));
    }
  }
}
