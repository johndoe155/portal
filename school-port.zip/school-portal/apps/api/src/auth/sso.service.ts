import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { jwtVerify, createRemoteJWKSet, type JWTVerifyOptions } from "jose";
import { config, type SsoProvider } from "../config";

/**
 * OIDC authorization-code flow helpers (Phase-1 §4: Entra ID + Google Workspace).
 * - state: HMAC-signed, self-contained (no server storage), 10 min TTL
 * - id_token: RS256 via the IdP's JWKS in production; HS256 accepted ONLY for
 *   dev mock IdPs (hmacSecret configured per provider)
 */

export interface SsoState { provider: string; nonce: string; ts: number; }

function hmac(data: string): string {
  return createHmac("sha256", config.appSecret).update(data).digest("base64url");
}

export function signState(provider: string): string {
  const payload = JSON.stringify({ provider, nonce: randomBytes(12).toString("base64url"), ts: Date.now() } satisfies SsoState);
  const b64 = Buffer.from(payload).toString("base64url");
  return `${b64}.${hmac(b64)}`;
}

export function verifyState(state: string, expectedProvider: string): SsoState {
  const [b64, sig] = state.split(".");
  if (!b64 || !sig) throw new Error("malformed state");
  const expect = Buffer.from(hmac(b64));
  const got = Buffer.from(sig);
  if (expect.length !== got.length || !timingSafeEqual(expect, got)) throw new Error("state signature mismatch");
  const parsed = JSON.parse(Buffer.from(b64, "base64url").toString()) as SsoState;
  if (parsed.provider !== expectedProvider) throw new Error("state provider mismatch");
  if (Date.now() - parsed.ts > config.ssoStateTtlMs) throw new Error("state expired");
  return parsed;
}

export function getProvider(name: string): SsoProvider {
  const p = config.sso[name];
  if (!p || !p.authUrl || !p.tokenUrl || !p.clientId) {
    const err: any = new Error(`SSO provider '${name}' is not configured`);
    err.code = "sso_not_configured";
    throw err;
  }
  return p;
}

export function authorizeUrl(p: SsoProvider, state: string): string {
  const u = new URL(p.authUrl);
  u.searchParams.set("response_type", "code");
  u.searchParams.set("client_id", p.clientId);
  u.searchParams.set("redirect_uri", redirectUri(p.name));
  u.searchParams.set("scope", p.scopes);
  u.searchParams.set("state", state);
  return u.toString();
}

export const redirectUri = (name: string) =>
  `${config.publicWebOrigin}/api/v1/auth/sso/${name}/callback`;

export async function exchangeCode(p: SsoProvider, code: string): Promise<string> {
  const res = await fetch(p.tokenUrl, {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded", accept: "application/json" },
    body: new URLSearchParams({
      grant_type: "authorization_code", code, redirect_uri: redirectUri(p.name),
      client_id: p.clientId, client_secret: p.clientSecret,
    }),
  });
  if (!res.ok) throw new Error(`token exchange failed: ${res.status}`);
  const body = await res.json() as { id_token?: string };
  if (!body.id_token) throw new Error("id_token missing from token response");
  return body.id_token;
}

export async function verifyIdToken(p: SsoProvider, idToken: string) {
  const opts: JWTVerifyOptions = { issuer: p.issuer || undefined, audience: p.clientId };
  if (p.jwksUrl) {
    const { payload } = await jwtVerify(idToken, createRemoteJWKSet(new URL(p.jwksUrl)), opts);
    return payload;
  }
  if (p.hmacSecret) {
    // dev/mock only — real IdPs must use jwksUrl (RS256)
    const { payload } = await jwtVerify(idToken, new TextEncoder().encode(p.hmacSecret), opts);
    return payload;
  }
  throw new Error("provider has neither jwksUrl nor hmacSecret");
}

export function claimsOf(payload: { sub?: string; email?: string; name?: string }) {
  if (!payload.sub || !payload.email) throw new Error("id_token missing sub/email");
  return { sub: String(payload.sub), email: String(payload.email), name: payload.name ? String(payload.name) : undefined };
}
