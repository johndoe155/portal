import { Body, Controller, Get, Post, Req, Res, ForbiddenException } from "@nestjs/common";
import type { Request, Response } from "express";
import { randomBytes } from "node:crypto";
import { LoginBody, TotpVerifyBody, RoleSwitchBody } from "@portal/contracts";
import { config } from "../config";
import { AuthService } from "./auth.service";

@Controller("auth")
export class AuthController {
  constructor(private auth: AuthService) {}

  @Get("providers")
  providers() {
    // SSO connections (Entra + Google) are configured per Phase-1 §4; local login always on.
    return { providers: ["local", "entra", "google"], parentEmailLogin: true };
  }

  @Post("login")
  async login(@Body() body: unknown, @Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const parsed = LoginBody.safeParse(body);
    if (!parsed.success) throw new ForbiddenException({ code: "validation", title: "Validation failed", detail: parsed.error.message });
    const out = await this.auth.login(parsed.data.email, parsed.data.password,
      { ip: req.ip, ua: req.headers["user-agent"] });
    res.cookie(config.sidCookie, out.token, {
      httpOnly: true, sameSite: "strict", secure: config.cookieSecure,
      path: "/", maxAge: 12 * 60 * 60 * 1000,
    });
    if (!req.cookies?.[config.csrfCookie]) {
      res.cookie(config.csrfCookie, randomBytes(16).toString("base64url"), {
        httpOnly: false, sameSite: "strict", secure: config.cookieSecure, path: "/",
      });
    }
    return { userId: out.userId, roles: out.roles, activeRole: out.activeRole,
      mfaRequired: out.mfaRequired, mfaVerified: out.mfaVerified };
  }

  @Get("session")
  session(@Req() req: Request) {
    const p = req.principal!;
    return { userId: p.userId, email: p.email, displayName: p.displayName, roles: p.roles,
      activeRole: p.activeRole, permissions: p.perms,
      mfaVerified: p.mfaVerified, mfaRequired: p.mfaRequired };
  }

  @Post("logout")
  async logout(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const out = await this.auth.logout(req.principal!);
    res.clearCookie(config.sidCookie);
    return out;
  }

  @Post("mfa/totp/enroll")
  enroll(@Req() req: Request) { return this.auth.totpEnroll(req.principal!); }

  @Post("mfa/totp/verify")
  async verify(@Body() body: unknown, @Req() req: Request) {
    const parsed = TotpVerifyBody.safeParse(body);
    if (!parsed.success) throw new ForbiddenException({ code: "validation", detail: parsed.error.message });
    return this.auth.totpVerify(req.principal!, parsed.data.code, { ip: req.ip, ua: req.headers["user-agent"] });
  }

  @Post("role/switch")
  switchRole(@Body() body: unknown, @Req() req: Request) {
    const parsed = RoleSwitchBody.safeParse(body);
    if (!parsed.success) throw new ForbiddenException({ code: "validation", detail: parsed.error.message });
    return this.auth.switchRole(req.principal!, parsed.data.role);
  }

}
