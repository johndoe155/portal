import { randomUUID } from "node:crypto";
import { sql } from "drizzle-orm";
import type { Db } from "./db/client";
import { withActor, SERVICE } from "./db/actor";
import {
  roles, rolePermissions, users, identities, userRoles, students, guardians,
  academicYears, terms, courses, courseSections, sectionStaff, enrollments,
  feeInvoices, exams, busRoutes, busStops, transportAssignments,
} from "./db/schema";
import { hashPassword } from "./crypto/password";

const PERMS: Record<string, string[]> = {
  super_admin: ["directory:read","directory:write","roles:read","roles:write","academics:read","academics:write","attendance:read","attendance:write","gradebook:read","gradebook:write","fees:read","fees:write","transport:read","transport:write","comms:write","audit:read","exports:write","family:read","self:read"],
  school_admin: ["directory:read","directory:write","roles:read","academics:read","academics:write","attendance:read","gradebook:read","fees:read","fees:write","transport:read","transport:write","comms:write","audit:read","exports:write"],
  registrar: ["directory:read","directory:write","academics:read","academics:write","attendance:read","gradebook:read"],
  counselor: ["directory:read","attendance:read","gradebook:read"],
  teacher: ["academics:read","attendance:read","attendance:write","gradebook:read","gradebook:write","messaging:write","schedule:read","self:read"],
  teacher_assistant: ["academics:read","attendance:read","attendance:write","gradebook:read","self:read"],
  student: ["self:read"],
  parent: ["family:read"],
  auditor: ["audit:read","directory:read","gradebook:read","attendance:read"],
};

export async function seed(db: Db): Promise<Record<string, string>> {
  return withActor(db, SERVICE, async (tx) => {
    const [{ n }] = await tx.select({ n: sql<number>`count(*)::int` }).from(users);
    if (n > 0) return {} as Record<string, string>; // already seeded

    for (const [code, perms] of Object.entries(PERMS)) {
      await tx.insert(roles).values({ code, name: code.replace(/_/g, " ") });
      for (const p of perms) await tx.insert(rolePermissions).values({ roleCode: code, permission: p });
    }

    const pw = await hashPassword("Passw0rd!");
    const mk = async (email: string, name: string, role: string) => {
      const id = randomUUID();
      await tx.insert(users).values({ id, email, displayName: name, passwordHash: pw });
      await tx.insert(identities).values({ userId: id, provider: "local", subject: email });
      await tx.insert(userRoles).values({ id: randomUUID(), userId: id, roleCode: role });
      return id;
    };
    const admin = await mk("admin@school.example", "Ada Admin", "school_admin");
    const root = await mk("root@school.example", "Rita Root", "super_admin");
    const t1 = await mk("t1@school.example", "Tayo Teacher", "teacher");
    const t2 = await mk("t2@school.example", "Tola Teacher", "teacher");
    const s1 = await mk("s1@school.example", "Sola Student", "student");
    const p1 = await mk("p1@school.example", "Paula Parent", "parent");

    await tx.insert(students).values({ userId: s1, admissionNo: "STU-0001", gradeLevel: 10 });
    await tx.insert(guardians).values({
      id: randomUUID(), studentUserId: s1, userId: p1,
      relationship: "mother", verifiedAt: new Date(),
    });

    const year = randomUUID();
    await tx.insert(academicYears).values({
      id: year, name: "2026/2027", startDate: "2026-09-01", endDate: "2027-07-31", isCurrent: true,
    });
    const term = randomUUID();
    await tx.insert(terms).values({ id: term, academicYearId: year, termNo: 1, name: "First Term" });

    const cMth = randomUUID(), cEng = randomUUID();
    await tx.insert(courses).values({ id: cMth, code: "MTH-101", title: "Mathematics" });
    await tx.insert(courses).values({ id: cEng, code: "ENG-101", title: "English" });

    const sec1 = randomUUID(), sec2 = randomUUID();
    await tx.insert(courseSections).values({ id: sec1, courseId: cMth, termId: term, name: "MTH-101 A" });
    await tx.insert(courseSections).values({ id: sec2, courseId: cEng, termId: term, name: "ENG-101 A" });

    await tx.insert(sectionStaff).values({ id: randomUUID(), sectionId: sec1, userId: t1, role: "teacher" });
    await tx.insert(sectionStaff).values({ id: randomUUID(), sectionId: sec2, userId: t2, role: "teacher" });
    await tx.insert(enrollments).values({ id: randomUUID(), studentUserId: s1, sectionId: sec1 });

    /* ── 5.4 demo data: fees, exam, transport ── */
    const inv = randomUUID();
    await tx.insert(feeInvoices).values({
      id: inv, studentUserId: s1, termId: term, label: "First Term Tuition",
      amountKobo: 15000000, status: "due", dueDate: "2026-10-31",  // ₦150,000.00
    });
    const exam = randomUUID();
    await tx.insert(exams).values({
      id: exam, sectionId: sec1, title: "First Term Examination",
      examDate: "2026-12-14", maxScore: "100", weightPct: "40",
    });
    const route = randomUUID();
    await tx.insert(busRoutes).values({
      id: route, name: "Route A — GRA Phase 2", driverName: "Chuka N.",
      driverPhone: "+234 803 000 0001", capacity: 30,
    });
    const stop = randomUUID();
    await tx.insert(busStops).values({
      id: stop, routeId: route, name: "Abuloma Junction", pickupTime: "07:10", seq: 3,
    });
    await tx.insert(transportAssignments).values({
      id: randomUUID(), studentUserId: s1, routeId: route, stopId: stop, termId: term,
    });

    return { admin, root, t1, t2, s1, p1, sec1, sec2, term, inv, exam, route, stop };
  });
}
