export interface SsoProvider {
  name: string;            // "entra" | "google" | "mock" ...
  issuer: string;
  authUrl: string;
  tokenUrl: string;
  clientId: string;
  clientSecret: string;
  scopes: string;
  jwksUrl?: string;        // RS256 verification (real IdPs)
  hmacSecret?: string;     // HS256 verification (dev/mock IdP only)
  jitRole?: string;        // auto-provision role for unknown users; empty = disabled
}

/** SSO_<NAME>_{ISSUER,AUTH_URL,TOKEN_URL,CLIENT_ID,CLIENT_SECRET,SCOPES,JWKS_URL,HMAC_SECRET,JIT_ROLE} */
function parseSsoProviders(): Record<string, SsoProvider> {
  const out: Record<string, SsoProvider> = {};
  for (const [k, v] of Object.entries(process.env)) {
    const m = /^SSO_([A-Z0-9]+)_(.+)$/.exec(k);
    if (!m || !v) continue;
    const name = m[1].toLowerCase();
    const p = (out[name] ??= {
      name, issuer: "", authUrl: "", tokenUrl: "", clientId: "", clientSecret: "", scopes: "openid email profile",
    });
    switch (m[2]) {
      case "ISSUER": p.issuer = v; break;
      case "AUTH_URL": p.authUrl = v; break;
      case "TOKEN_URL": p.tokenUrl = v; break;
      case "CLIENT_ID": p.clientId = v; break;
      case "CLIENT_SECRET": p.clientSecret = v; break;
      case "SCOPES": p.scopes = v; break;
      case "JWKS_URL": p.jwksUrl = v; break;
      case "HMAC_SECRET": p.hmacSecret = v; break;
      case "JIT_ROLE": p.jitRole = v; break;
    }
  }
  return out;
}

export const config = {
  port: Number(process.env.PORT ?? 8080),
  /** false in dev/tests (http); true in prod behind TLS */
  cookieSecure: process.env.COOKIE_SECURE !== "false",
  /** staff MFA step-up enforcement; off only for local demo */
  mfaEnforce: process.env.MFA_ENFORCE !== "false",
  appSecret: process.env.APP_SECRET ?? "dev-only-secret-change-me-32chars!",
  sessionTtlHoursStaff: 12,
  sessionTtlHoursUser: 24,
  sidCookie: "sid",
  csrfCookie: "csrf",
  /** Paystack webhook HMAC SHA-512 secret; unset ⇒ webhook returns 503 */
  paystackSecret: process.env.PAYSTACK_SECRET ?? "",
  /** web origin the browser lives on — SSO redirects + cookie scope (BFF) */
  publicWebOrigin: process.env.PUBLIC_WEB_ORIGIN ?? "http://127.0.0.1:3000",
  sso: parseSsoProviders(),
  ssoStateTtlMs: 10 * 60 * 1000,
};
export type Config = typeof config;
