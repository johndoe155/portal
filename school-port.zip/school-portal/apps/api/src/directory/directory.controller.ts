import {
  Body, ConflictException, Controller, Delete, Get, Inject, NotFoundException, Param, Post, Query,
  Req, UnprocessableEntityException,
} from "@nestjs/common";
import { eq, sql, and, isNull } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import type { Db } from "../db/client";
import { DB_TOKEN } from "../db/token";
import { withActor, SERVICE } from "../db/actor";
import { users, students, userRoles, identities, roles } from "../db/schema";
import { Perm } from "../common/guards";
import { insertAudit } from "../common/audit";
import { hashPassword } from "../crypto/password";
import { UserCreateBody, RoleGrantBody } from "@portal/contracts";
import type { Request } from "express";

@Controller()
export class DirectoryController {
  constructor(@Inject(DB_TOKEN) private db: Db) {}

  @Get("users")
  @Perm("directory:read")
  async listUsers(@Req() req: Request, @Query("page") page = "1", @Query("per") per = "25") {
    const p = req.principal!;
    const limit = Math.min(Number(per) || 25, 100);
    const offset = (Math.max(Number(page) || 1, 1) - 1) * limit;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const rows = await tx.select({
        id: users.id, email: users.email, displayName: users.displayName, status: users.status,
      }).from(users).limit(limit).offset(offset);
      const [{ total }] = await tx.select({ total: sql<number>`count(*)::int` }).from(users);
      return { data: rows, meta: { page: Number(page) || 1, per: limit, total } };
    });
  }

  @Get("students/:id")
  @Perm("directory:read")
  async studentProfile(@Req() req: Request, @Param("id") id: string) {
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const [row] = await tx.select({
        userId: students.userId, admissionNo: students.admissionNo,
        gradeLevel: students.gradeLevel, status: students.status,
        displayName: users.displayName, email: users.email,
      }).from(students).innerJoin(users, eq(users.id, students.userId))
        .where(and(eq(students.userId, id))).limit(1);
      if (!row) throw new NotFoundException({ code: "not_found" });
      return row;
    });
  }

  @Get("users/:id/roles")
  @Perm("roles:read")
  async userRoles(@Req() req: Request, @Param("id") id: string) {
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const rows = await tx.select().from(userRoles).where(eq(userRoles.userId, id));
      return { data: rows };
    });
  }

  /** registrar lookup by admission number (enrollment UX) */
  @Get("students-lookup")
  @Perm("directory:read")
  async lookup(@Req() req: Request, @Query("admission_no") admissionNo: string) {
    if (!admissionNo) throw new UnprocessableEntityException({ code: "validation", detail: "admission_no required" });
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const [row] = await tx.select({
        userId: students.userId, admissionNo: students.admissionNo,
        gradeLevel: students.gradeLevel, displayName: users.displayName,
      }).from(students).innerJoin(users, eq(users.id, students.userId))
        .where(eq(students.admissionNo, admissionNo.toUpperCase())).limit(1);
      if (!row) throw new NotFoundException({ code: "not_found" });
      return row;
    });
  }

  /** Phase 5.3: admin creates accounts. identities_* is service-only in RLS,
   *  so the write transaction runs as SERVICE after the capability gate. */
  @Post("users")
  @Perm("directory:write")
  async createUser(@Req() req: Request, @Body() body: unknown) {
    const parsed = UserCreateBody.safeParse(body);
    if (!parsed.success) {
      throw new UnprocessableEntityException({ code: "validation", detail: parsed.error.message });
    }
    const p = req.principal!;
    const b = parsed.data;
    const out = await withActor(this.db, SERVICE, async (tx) => {
      const [dupe] = await tx.select({ id: users.id }).from(users)
        .where(eq(sql`lower(${users.email})`, b.email.toLowerCase())).limit(1);
      if (dupe) throw new ConflictException({ code: "email_taken", detail: b.email });
      for (const r of b.roles) {
        const [role] = await tx.select({ code: roles.code }).from(roles).where(eq(roles.code, r)).limit(1);
        if (!role) throw new UnprocessableEntityException({ code: "unknown_role", detail: r });
      }
      const [user] = await tx.insert(users).values({
        email: b.email, displayName: b.display_name, passwordHash: await hashPassword(b.password),
      }).returning({ id: users.id, email: users.email, displayName: users.displayName });
      await tx.insert(identities).values({ userId: user.id, provider: "local", subject: b.email });
      for (const r of b.roles) {
        await tx.insert(userRoles).values({ id: randomUUID(), userId: user.id, roleCode: r });
      }
      await insertAudit(tx, { actorUserId: p.userId, action: "user.created",
        entityType: "user", entityId: user.id, after: { roles: b.roles }, ip: req.ip });
      return user;
    });
    return out;
  }

  @Post("users/:id/roles")
  @Perm("roles:write")
  async grantRole(@Req() req: Request, @Param("id") id: string, @Body() body: unknown) {
    const parsed = RoleGrantBody.safeParse(body);
    if (!parsed.success) {
      throw new UnprocessableEntityException({ code: "validation", detail: parsed.error.message });
    }
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const [user] = await tx.select({ id: users.id }).from(users).where(eq(users.id, id)).limit(1);
      if (!user) throw new NotFoundException({ code: "not_found" });
      const [active] = await tx.select({ id: userRoles.id }).from(userRoles)
        .where(and(eq(userRoles.userId, id), eq(userRoles.roleCode, parsed.data.role_code),
          isNull(userRoles.revokedAt))).limit(1);
      if (active) throw new ConflictException({ code: "role_already_granted" });
      const [row] = await tx.insert(userRoles)
        .values({ id: randomUUID(), userId: id, roleCode: parsed.data.role_code }).returning();
      await insertAudit(tx, { actorUserId: p.userId, action: "role.granted",
        entityType: "user", entityId: id, after: { role: parsed.data.role_code }, ip: req.ip });
      return row;
    });
  }

  @Delete("users/:id/roles/:roleCode")
  @Perm("roles:write")
  async revokeRole(@Req() req: Request, @Param("id") id: string, @Param("roleCode") roleCode: string) {
    const p = req.principal!;
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      const rows = await tx.update(userRoles)
        .set({ revokedAt: new Date() })
        .where(and(eq(userRoles.userId, id), eq(userRoles.roleCode, roleCode),
          isNull(userRoles.revokedAt))).returning();
      if (rows.length === 0) throw new NotFoundException({ code: "not_found" });
      await insertAudit(tx, { actorUserId: p.userId, action: "role.revoked",
        entityType: "user", entityId: id, after: { role: roleCode }, ip: req.ip });
      return { revoked: rows.length };
    });
  }
}
