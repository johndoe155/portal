import {
  Body, Controller, ForbiddenException, Get, Inject, NotFoundException, Param, Post, Query, Req,
} from "@nestjs/common";
import { and, eq, isNotNull, sql } from "drizzle-orm";
import type { Db } from "../db/client";
import { DB_TOKEN } from "../db/token";
import { withActor, SERVICE } from "../db/actor";
import {
  reportCards, terms, enrollments, courseSections, courses, grades,
  attendanceRecords, attendanceSessions, guardians, students, users,
} from "../db/schema";
import { Perm } from "../common/guards";
import { insertAudit } from "../common/audit";
import { ReportGenerateBody } from "@portal/contracts";
import type { Request } from "express";

const ADMIN_ROLES = new Set(["super_admin", "school_admin"]);

/** Report-card snapshots: point-in-time JSON per student+term (exports:write to generate). */
@Controller()
export class ReportsController {
  constructor(@Inject(DB_TOKEN) private db: Db) {}

  @Post("report-cards/generate")
  @Perm("exports:write")
  async generate(@Req() req: Request, @Body() body: unknown) {
    const parsed = ReportGenerateBody.safeParse(body ?? {});
    if (!parsed.success) throw new ForbiddenException({ code: "validation", detail: parsed.error.message });
    const p = req.principal!;

    // read phase runs as the admin actor (RLS still applies); writes run as SERVICE
    const termId = parsed.data.term_id;
    const data = await withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      let term = termId
        ? (await tx.select().from(terms).where(eq(terms.id, termId)).limit(1))[0]
        : (await tx.select().from(terms).limit(1))[0];
      if (!term) throw new NotFoundException({ code: "no_term" });
      const sections = await tx.select({
        id: courseSections.id, name: courseSections.name, code: courses.code,
      }).from(courseSections).innerJoin(courses, eq(courses.id, courseSections.courseId))
        .where(eq(courseSections.termId, term.id));
      const rows: { student: string; snapshot: Record<string, unknown> }[] = [];
      const studentIds = await tx.selectDistinct({ id: enrollments.studentUserId }).from(enrollments)
        .where(and(eq(enrollments.status, "enrolled"),
          sql`${enrollments.sectionId} IN (${sql.join(sections.map((s) => s.id), sql`, `)})`));
      for (const { id: stuId } of studentIds) {
        const perSection = [];
        for (const sec of sections) {
          const [enrolled] = await tx.select({ id: enrollments.id }).from(enrollments)
            .where(and(eq(enrollments.sectionId, sec.id), eq(enrollments.studentUserId, stuId),
              eq(enrollments.status, "enrolled"))).limit(1);
          if (!enrolled) continue;
          const g = await tx.select({
            label: grades.label, points: grades.points, maxPoints: grades.maxPoints,
            sourceType: grades.sourceType, feedbackText: grades.feedbackText,
          }).from(grades).where(and(eq(grades.sectionId, sec.id), eq(grades.studentUserId, stuId),
            isNotNull(grades.releasedAt)));
          const att = await tx.select({
            status: attendanceRecords.status, n: sql<number>`count(*)::int`,
          }).from(attendanceRecords)
            .innerJoin(attendanceSessions, eq(attendanceSessions.id, attendanceRecords.sessionId))
            .where(and(eq(attendanceRecords.studentUserId, stuId),
              eq(attendanceSessions.sectionId, sec.id)))
            .groupBy(attendanceRecords.status);
          perSection.push({
            section: sec.name, course: sec.code, grades: g,
            attendance: Object.fromEntries(att.map((a) => [a.status, a.n])),
          });
        }
        rows.push({ student: stuId, snapshot: { term: term.name, sections: perSection,
          generatedAt: new Date().toISOString() } });
      }
      return { termId: term.id, rows };
    });

    const out = await withActor(this.db, SERVICE, async (tx) => {
      for (const r of data.rows) {
        await tx.insert(reportCards).values({
          studentUserId: r.student, termId: data.termId,
          snapshot: r.snapshot, generatedBy: p.userId,
        }).onConflictDoUpdate({
          target: [reportCards.studentUserId, reportCards.termId],
          set: { snapshot: r.snapshot, generatedBy: p.userId, generatedAt: new Date() },
        });
      }
      await insertAudit(tx, { actorUserId: p.userId, action: "report_cards.generated",
        entityType: "term", entityId: data.termId, after: { count: data.rows.length }, ip: req.ip });
      return { generated: data.rows.length, termId: data.termId };
    });
    return out;
  }

  /** self / guardian / admin — RLS is the backstop; role check here gives clean errors */
  @Get("students/:id/report-card")
  async read(@Req() req: Request, @Param("id") id: string, @Query("term_id") termId?: string) {
    const p = req.principal!;
    if (p.activeRole === "student" && p.userId !== id) {
      throw new ForbiddenException({ code: "missing_capability", detail: "own report card only" });
    }
    const isAdmin = ADMIN_ROLES.has(p.activeRole);
    return withActor(this.db, { userId: p.userId, role: p.activeRole }, async (tx) => {
      if (p.activeRole === "parent") {
        const [g] = await tx.select({ id: guardians.id }).from(guardians)
          .where(and(eq(guardians.userId, p.userId), eq(guardians.studentUserId, id),
            sql`${guardians.verifiedAt} IS NOT NULL`, sql`${guardians.endedAt} IS NULL`)).limit(1);
        if (!g) throw new NotFoundException({ code: "not_found" });
      } else if (!isAdmin && p.activeRole !== "student") {
        throw new ForbiddenException({ code: "missing_capability" });
      }
      const filter = termId
        ? and(eq(reportCards.studentUserId, id), eq(reportCards.termId, termId))
        : eq(reportCards.studentUserId, id);
      const rows = await tx.select().from(reportCards).where(filter);
      if (rows.length === 0) throw new NotFoundException({ code: "not_found", detail: "no snapshot yet" });
      return { data: rows };
    });
  }
}
