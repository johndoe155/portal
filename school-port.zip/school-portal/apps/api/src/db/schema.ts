import {
  pgTable, uuid, text, timestamp, boolean, numeric, smallint, date, jsonb,
  primaryKey, unique, bigint,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull(),
  passwordHash: text("password_hash"),
  displayName: text("display_name").notNull(),
  status: text("status").notNull().default("active"),
  directoryOptOut: boolean("directory_opt_out").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }),
});

export const identities = pgTable("identities", {
  userId: uuid("user_id").notNull(),
  provider: text("provider").notNull(),
  subject: text("subject").notNull(),
  emailSnapshot: text("email_snapshot"),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({ pk: primaryKey({ columns: [t.provider, t.subject] }) }));

export const sessions = pgTable("sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  tokenHash: text("token_hash").notNull(),
  activeRole: text("active_role").notNull(),
  amr: text("amr").notNull().default("[]"),
  mfaVerifiedAt: timestamp("mfa_verified_at", { withTimezone: true }),
  ip: text("ip"),
  userAgent: text("user_agent"),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  lastActiveAt: timestamp("last_active_at", { withTimezone: true }),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const mfaFactors = pgTable("mfa_factors", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  kind: text("kind").notNull(),
  label: text("label").notNull(),
  secretEnc: text("secret_enc").notNull(),
  lastUsedAt: timestamp("last_used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const roles = pgTable("roles", {
  code: text("code").primaryKey(),
  name: text("name").notNull(),
  isSystem: boolean("is_system").notNull().default(true),
});

export const userRoles = pgTable("user_roles", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  roleCode: text("role_code").notNull(),
  grantedAt: timestamp("granted_at", { withTimezone: true }).notNull().defaultNow(),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
});

export const rolePermissions = pgTable("role_permissions", {
  roleCode: text("role_code").notNull(),
  permission: text("permission").notNull(),
}, (t) => ({ pk: primaryKey({ columns: [t.roleCode, t.permission] }) }));

export const students = pgTable("students", {
  userId: uuid("user_id").primaryKey(),
  admissionNo: text("admission_no").notNull(),
  gradeLevel: smallint("grade_level").notNull(),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const guardians = pgTable("guardians", {
  id: uuid("id").primaryKey().defaultRandom(),
  studentUserId: uuid("student_user_id").notNull(),
  userId: uuid("user_id").notNull(),
  relationship: text("relationship").notNull(),
  canView: boolean("can_view").notNull().default(true),
  verifiedAt: timestamp("verified_at", { withTimezone: true }),
  endedAt: timestamp("ended_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const academicYears = pgTable("academic_years", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  isCurrent: boolean("is_current").notNull().default(false),
});

export const terms = pgTable("terms", {
  id: uuid("id").primaryKey().defaultRandom(),
  academicYearId: uuid("academic_year_id").notNull(),
  termNo: smallint("term_no").notNull(),
  name: text("name").notNull(),
});

export const courses = pgTable("courses", {
  id: uuid("id").primaryKey().defaultRandom(),
  code: text("code").notNull(),
  title: text("title").notNull(),
});

export const courseSections = pgTable("course_sections", {
  id: uuid("id").primaryKey().defaultRandom(),
  courseId: uuid("course_id").notNull(),
  termId: uuid("term_id").notNull(),
  name: text("name").notNull(),
  status: text("status").notNull().default("active"),
});

export const sectionStaff = pgTable("section_staff", {
  id: uuid("id").primaryKey().defaultRandom(),
  sectionId: uuid("section_id").notNull(),
  userId: uuid("user_id").notNull(),
  role: text("role").notNull(),
});

export const enrollments = pgTable("enrollments", {
  id: uuid("id").primaryKey().defaultRandom(),
  studentUserId: uuid("student_user_id").notNull(),
  sectionId: uuid("section_id").notNull(),
  status: text("status").notNull().default("enrolled"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const attendanceSessions = pgTable("attendance_sessions", {
  id: uuid("id").primaryKey().defaultRandom(),
  sectionId: uuid("section_id").notNull(),
  date: date("date").notNull(),
  takenBy: uuid("taken_by"),
  status: text("status").notNull().default("draft"),
  finalizedAt: timestamp("finalized_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const attendanceRecords = pgTable("attendance_records", {
  sessionId: uuid("session_id").notNull(),
  studentUserId: uuid("student_user_id").notNull(),
  status: text("status").notNull(),
  note: text("note"),
}, (t) => ({ pk: primaryKey({ columns: [t.sessionId, t.studentUserId] }) }));

export const grades = pgTable("grades", {
  id: uuid("id").primaryKey().defaultRandom(),
  studentUserId: uuid("student_user_id").notNull(),
  sectionId: uuid("section_id").notNull(),
  sourceType: text("source_type").notNull(),
  sourceId: uuid("source_id"),
  label: text("label").notNull(),
  points: numeric("points", { precision: 6, scale: 2 }).notNull(),
  maxPoints: numeric("max_points", { precision: 6, scale: 2 }).notNull(),
  weightPct: numeric("weight_pct", { precision: 5, scale: 2 }),
  gradedBy: uuid("graded_by"),
  gradedAt: timestamp("graded_at", { withTimezone: true }).notNull().defaultNow(),
  releasedAt: timestamp("released_at", { withTimezone: true }),
  feedbackText: text("feedback_text"),
});

export const gradeRevisions = pgTable("grade_revisions", {
  id: uuid("id").primaryKey().defaultRandom(),
  gradeId: uuid("grade_id").notNull(),
  prevPoints: numeric("prev_points", { precision: 6, scale: 2 }),
  newPoints: numeric("new_points", { precision: 6, scale: 2 }).notNull(),
  changedBy: uuid("changed_by").notNull(),
  reason: text("reason").notNull(),
  changedAt: timestamp("changed_at", { withTimezone: true }).notNull().defaultNow(),
});

export const auditLog = pgTable("audit_log", {
  id: uuid("id").primaryKey().defaultRandom(),
  actorUserId: uuid("actor_user_id"),
  action: text("action").notNull(),
  entityType: text("entity_type"),
  entityId: uuid("entity_id"),
  beforeJson: jsonb("before_json"),
  afterJson: jsonb("after_json"),
  ip: text("ip"),
  userAgent: text("user_agent"),
  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
  rowHash: text("row_hash").notNull(),
});

/* ── Phase 5.3: messaging, notifications, push, report cards (0002) ── */

export const messageThreads = pgTable("message_threads", {
  id: uuid("id").primaryKey().defaultRandom(),
  studentUserId: uuid("student_user_id").notNull(),
  createdBy: uuid("created_by").notNull(),
  subject: text("subject").notNull(),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  closedAt: timestamp("closed_at", { withTimezone: true }),
});

export const messages = pgTable("messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  threadId: uuid("thread_id").notNull(),
  senderUserId: uuid("sender_user_id").notNull(),
  /** denormalized snapshot — guardians cannot join staff rows in users (RLS) */
  senderName: text("sender_name").notNull(),
  bodyText: text("body_text").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  recipientUserId: uuid("recipient_user_id").notNull(),
  channel: text("channel").notNull(),
  kind: text("kind").notNull(),
  payload: jsonb("payload").notNull().default({}),
  status: text("status").notNull().default("queued"),
  attempts: smallint("attempts").notNull().default(0),
  lastError: text("last_error"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  sentAt: timestamp("sent_at", { withTimezone: true }),
});

export const pushSubscriptions = pgTable("push_subscriptions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  endpoint: text("endpoint").notNull().unique(),
  p256dh: text("p256dh"),
  authKey: text("auth_key"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const reportCards = pgTable("report_cards", {
  id: uuid("id").primaryKey().defaultRandom(),
  studentUserId: uuid("student_user_id").notNull(),
  termId: uuid("term_id").notNull(),
  snapshot: jsonb("snapshot").notNull(),
  generatedBy: uuid("generated_by"),
  generatedAt: timestamp("generated_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({ uq: unique().on(t.studentUserId, t.termId) }));

/* ── Phase 5.4: fees (kobo), exams, transport (0003) ── */

export const feeInvoices = pgTable("fee_invoices", {
  id: uuid("id").primaryKey().defaultRandom(),
  studentUserId: uuid("student_user_id").notNull(),
  termId: uuid("term_id").notNull(),
  label: text("label").notNull(),
  amountKobo: bigint("amount_kobo", { mode: "number" }).notNull(),
  status: text("status").notNull().default("due"),
  dueDate: date("due_date"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const feePayments = pgTable("fee_payments", {
  id: uuid("id").primaryKey().defaultRandom(),
  invoiceId: uuid("invoice_id").notNull(),
  amountKobo: bigint("amount_kobo", { mode: "number" }).notNull(),
  channel: text("channel").notNull().default("paystack"),
  gatewayRef: text("gateway_ref").unique(),
  status: text("status").notNull().default("pending"),
  paidBy: uuid("paid_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  paidAt: timestamp("paid_at", { withTimezone: true }),
});

export const exams = pgTable("exams", {
  id: uuid("id").primaryKey().defaultRandom(),
  sectionId: uuid("section_id").notNull(),
  title: text("title").notNull(),
  examDate: date("exam_date").notNull(),
  maxScore: numeric("max_score", { precision: 6, scale: 2 }).notNull().default("100"),
  weightPct: numeric("weight_pct", { precision: 5, scale: 2 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const busRoutes = pgTable("bus_routes", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  driverName: text("driver_name"),
  driverPhone: text("driver_phone"),
  capacity: smallint("capacity"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const busStops = pgTable("bus_stops", {
  id: uuid("id").primaryKey().defaultRandom(),
  routeId: uuid("route_id").notNull(),
  name: text("name").notNull(),
  pickupTime: text("pickup_time"),
  seq: smallint("seq").notNull().default(0),
});

export const transportAssignments = pgTable("transport_assignments", {
  id: uuid("id").primaryKey().defaultRandom(),
  studentUserId: uuid("student_user_id").notNull(),
  routeId: uuid("route_id").notNull(),
  stopId: uuid("stop_id"),
  termId: uuid("term_id").notNull(),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  endedAt: timestamp("ended_at", { withTimezone: true }),
});
