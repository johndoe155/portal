import { PGlite } from "@electric-sql/pglite";
import { drizzle, PgliteDatabase } from "drizzle-orm/pglite";
import * as schema from "./schema";

export type Db = PgliteDatabase<typeof schema>;

/**
 * Dev/tests: in-process PGlite (real Postgres, RLS honoured via FORCE).
 * Production: swap for Neon/Supabase via drizzle's node-postgres driver — schema & SQL unchanged.
 */
export function createDb(dataDir?: string): { pg: PGlite; db: Db } {
  const pg = new PGlite(dataDir);
  const db = drizzle(pg, { schema });
  return { pg, db };
}
