import * as fs from "node:fs";
import * as path from "node:path";
import type { PGlite } from "@electric-sql/pglite";

export const MIGRATIONS_DIR = path.resolve(__dirname, "..", "..", "..", "..", "db", "migrations");

export async function runMigrations(pg: PGlite): Promise<string[]> {
  const files = fs.readdirSync(MIGRATIONS_DIR).filter((f) => f.endsWith(".sql")).sort();
  const applied: string[] = [];
  for (const f of files) {
    const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, f), "utf8");
    await pg.exec(sql);
    applied.push(f);
  }
  return applied;
}
