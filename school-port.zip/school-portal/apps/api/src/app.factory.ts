import "reflect-metadata";
import { NestFactory, Reflector } from "@nestjs/core";
import cookieParser from "cookie-parser";
import { json as expressJson } from "express";
import { AppModule } from "./app.module";
import type { Db } from "./db/client";
import { makeSessionMiddleware } from "./common/session.middleware";
import { ProblemFilter } from "./common/problem";
import { CsrfGuard, PermGuard } from "./common/guards";
import { startWorker } from "./notify/notify.service";

export async function createApp(db: Db) {
  // bodyParser:false + manual express.json with `verify` — the webhook route
  // needs the untouched bytes for Paystack's HMAC-SHA512 signature check.
  const app = await NestFactory.create(AppModule.register(db), { logger: false, bodyParser: false });
  const express = app.getHttpAdapter().getInstance();
  express.use(expressJson({
    limit: "1mb",
    verify: (req: any, _res, buf) => { req.rawBody = buf; },
  }));
  express.use(cookieParser());
  express.use(makeSessionMiddleware(db));
  app.setGlobalPrefix("api/v1");
  app.useGlobalFilters(new ProblemFilter());
  app.useGlobalGuards(new CsrfGuard(), new PermGuard(new Reflector()));
  await app.init();
  // dev/single-node: outbox worker runs in-process (unref'd interval).
  // production: WORKER_INPROC=false + `npm run worker` beside real Postgres.
  if (process.env.WORKER_INPROC !== "false") {
    const stop = startWorker(db, { pushSinkFile: process.env.PUSH_SINK_FILE ?? "data/push-outbox.jsonl" });
    app.enableShutdownHooks?.();
    process.once("beforeExit", stop);
  }
  return app;
}
