// Portal load test — k6 (Phase 5.4)
// Run:  k6 run -e BASE=http://127.0.0.1:8080 apps/api/loadtest/portal.js
//       k6 run --vus 200 --duration 60s ...   (spike)
//
// Covers the hot paths that matter for a school portal at bell-rush:
//   • student login (no MFA) + dashboard reads
//   • parent login + read-only child views
//   • teacher attendance register writes (idempotent) after password+TOTP
// Thresholds are set for a single-node dev box; tighten for production SLOs.

import http from "k6/http";
import { check, sleep, group } from "k6";
import { SharedArray } from "k6/data";
import crypto from "k6/crypto";
import encoding from "k6/encoding";

const BASE = __ENV.BASE ?? "http://127.0.0.1:8080";
const PASSWORD = __ENV.PASSWORD ?? "Passw0rd!";

export const options = {
  scenarios: {
    // steady bell-rush traffic
    steady: {
      executor: "ramping-vus",
      startVUs: 0,
      stages: [
        { duration: "30s", target: 50 },   // ramp up
        { duration: "1m", target: 50 },    // sustain
        { duration: "20s", target: 0 },    // ramp down
      ],
      gracefulRampDown: "10s",
    },
    // short spike (whole-school login at 07:45)
    spike: {
      executor: "ramping-arrival-rate",
      startRate: 10,
      timeUnit: "1s",
      preAllocatedVUs: 200,
      maxVUs: 400,
      stages: [
        { duration: "10s", target: 100 },
        { duration: "30s", target: 300 },  // spike
        { duration: "20s", target: 20 },
      ],
      startTime: "2m10s",
    },
  },
  thresholds: {
    http_req_failed: ["rate<0.01"],        // <1% errors
    http_req_duration: ["p(95)<600"],      // 95th pct < 600ms
    "checks": ["rate>0.98"],
  },
};

const jsonHeaders = { "Content-Type": "application/json" };

function jar() { return new http.CookieJar(); }

// ── TOTP (RFC 6238, SHA-1, 6-digit, 30s) so teacher flows can pass MFA ──
function base32Decode(s) {
  const alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let bits = 0, value = 0, out = [];
  for (const c of s.replace(/=+$/, "").toUpperCase()) {
    const idx = alpha.indexOf(c);
    if (idx < 0) continue;
    value = (value << 5) | idx; bits += 5;
    if (bits >= 8) { out.push((value >>> (bits - 8)) & 0xff); bits -= 8; }
  }
  return new Uint8Array(out);
}
function totp(secret, atMs = Date.now()) {
  const counter = Math.floor(atMs / 1000 / 30);
  const buf = new ArrayBuffer(8);
  const view = new DataView(buf);
  view.setUint32(0, Math.floor(counter / 4294967296));
  view.setUint32(4, counter >>> 0);
  const hmac = crypto.hmac("sha1", base32Decode(secret), new Uint8Array(buf), "binary");
  const offset = hmac[hmac.length - 1] & 0x0f;
  const code = ((hmac[offset] & 0x7f) << 24) | (hmac[offset + 1] << 16) | (hmac[offset + 2] << 8) | hmac[offset + 3];
  return String(code % 1000000).padStart(6, "0");
}

function login(email) {
  const res = http.post(`${BASE}/api/v1/auth/login`, JSON.stringify({ email, password: PASSWORD }), jsonHeaders);
  check(res, { "login 201": (r) => r.status === 201 });
  return res;
}

function completeMfa(secretCookieJar, email) {
  login(email);
  const enroll = http.post(`${BASE}/api/v1/auth/mfa/totp/enroll`, null, {});
  if (enroll.status !== 201) return false;
  const secret = JSON.parse(enroll.body).secret;
  const v = http.post(`${BASE}/api/v1/auth/mfa/totp/verify`, JSON.stringify({ code: totp(secret) }), jsonHeaders);
  return v.status === 201;
}

export default function () {
  const roll = Math.random();
  if (roll < 0.5) studentFlow();
  else if (roll < 0.8) parentFlow();
  else teacherFlow();
  sleep(Math.random() * 2 + 0.5);
}

function studentFlow() {
  group("student", () => {
    const res = login("s1@school.example");
    if (res.status !== 201) return;
    const sid = res.cookies?.sid?.[0]?.value;
    const csrf = res.cookies?.csrf?.[0]?.value;
    const h = { Cookie: `sid=${sid}; csrf=${csrf}`, "x-csrf": csrf };
    const grades = http.get(`${BASE}/api/v1/student/grades`, { headers: h });
    check(grades, { "student grades 200": (r) => r.status === 200 });
    const att = http.get(`${BASE}/api/v1/student/attendance`, { headers: h });
    check(att, { "student attendance 200": (r) => r.status === 200 });
    const exams = http.get(`${BASE}/api/v1/student/exams`, { headers: h });
    check(exams, { "student exams 200": (r) => r.status === 200 });
  });
}

function parentFlow() {
  group("parent", () => {
    const res = login("p1@school.example");
    if (res.status !== 201) return;
    const sid = res.cookies?.sid?.[0]?.value;
    const csrf = res.cookies?.csrf?.[0]?.value;
    const h = { Cookie: `sid=${sid}; csrf=${csrf}`, "x-csrf": csrf };
    const kids = http.get(`${BASE}/api/v1/parent/children`, { headers: h });
    check(kids, { "parent children 200": (r) => r.status === 200 });
    const data = JSON.parse(kids.body).data ?? [];
    if (data[0]) {
      const id = data[0].studentUserId;
      http.get(`${BASE}/api/v1/parent/children/${id}/grades`, { headers: h });
      http.get(`${BASE}/api/v1/parent/children/${id}/fees`, { headers: h });
      http.get(`${BASE}/api/v1/parent/children/${id}/transport`, { headers: h });
    }
  });
}

function teacherFlow() {
  group("teacher", () => {
    // one enrol per VU lifetime is enough; verify a fresh code each iteration
    login("t1@school.example");
    const enroll = http.post(`${BASE}/api/v1/auth/mfa/totp/enroll`, null, {});
    if (enroll.status !== 201) return;
    const secret = JSON.parse(enroll.body).secret;
    const v = http.post(`${BASE}/api/v1/auth/mfa/totp/verify`, JSON.stringify({ code: totp(secret) }), jsonHeaders);
    if (v.status !== 201) return;
    const sid = v.cookies?.sid?.[0]?.value ?? enroll.cookies?.sid?.[0]?.value;
    const csrf = v.cookies?.csrf?.[0]?.value ?? enroll.cookies?.csrf?.[0]?.value;
    const h = { Cookie: `sid=${sid}; csrf=${csrf}`, "x-csrf": csrf, "Content-Type": "application/json" };
    const sections = http.get(`${BASE}/api/v1/sections`, { headers: h });
    check(sections, { "teacher sections 200": (r) => r.status === 200 });
    const data = JSON.parse(sections.body).data ?? [];
    if (data[0]) {
      const gb = http.get(`${BASE}/api/v1/sections/${data[0].id}/gradebook`, { headers: h });
      check(gb, { "gradebook read 200": (r) => r.status === 200 });
    }
  });
}
