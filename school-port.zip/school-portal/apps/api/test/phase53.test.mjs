import test, { before, after } from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { existsSync, readFileSync, unlinkSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

// ── env BEFORE config module loads (config reads process.env at import) ──
process.env.COOKIE_SECURE = "false";
process.env.WORKER_INPROC = "false";           // tests drive the worker manually
process.env.PUBLIC_WEB_ORIGIN = "http://127.0.0.1:3000";
const IDP = 9310;
for (const name of ["ENTRA", "GOOGLE"]) {
  process.env[`SSO_${name}_ISSUER`] = `http://127.0.0.1:${IDP}`;
  process.env[`SSO_${name}_AUTH_URL`] = `http://127.0.0.1:${IDP}/authorize`;
  process.env[`SSO_${name}_TOKEN_URL`] = `http://127.0.0.1:${IDP}/token`;
  process.env[`SSO_${name}_CLIENT_ID`] = `${name.toLowerCase()}-client`;
  process.env[`SSO_${name}_CLIENT_SECRET`] = "mock-secret-value";
  process.env[`SSO_${name}_HMAC_SECRET`] = "mock-secret";
}
process.env.SSO_ENTRA_JIT_ROLE = "student";     // entra (mock IdP): JIT provisioning ON
// GOOGLE: no JIT role → unprovisioned identities are refused

const require = createRequire(import.meta.url);
const { createDb } = require("../dist/db/client.js");
const { runMigrations } = require("../dist/db/migrate.js");
const { seed } = require("../dist/seed.js");
const { createApp } = require("../dist/app.factory.js");
const { totpCode } = require("../dist/crypto/totp.js");
const { withActor, SERVICE } = require("../dist/db/actor.js");
const { processQueue, runDigest } = require("../dist/notify/notify.service.js");
const { notifications } = require("../dist/db/schema.js");
const { eq } = require("drizzle-orm");
const request = require("supertest");
const { startMockIdp } = await import("./mock-idp.mjs");

let app, server, db, ids, idp;
const jars = {};
const tmp = mkdtempSync(join(tmpdir(), "portal53-"));
const PUSH_SINK = join(tmp, "push-outbox.jsonl");

function cookiesOf(res) {
  const out = {};
  for (const c of res.headers["set-cookie"] ?? []) {
    const [pair] = c.split(";");
    const i = pair.indexOf("=");
    out[pair.slice(0, i)] = pair.slice(i + 1);
  }
  return out;
}
function auth(name) { return { Cookie: `sid=${jars[name].sid}; csrf=${jars[name].csrf}`, "x-csrf": jars[name].csrf }; }
async function loginAs(name, email) {
  const res = await request(server).post("/api/v1/auth/login").send({ email, password: "Passw0rd!" });
  assert.equal(res.status, 201, JSON.stringify(res.body));
  jars[name] = { ...cookiesOf(res) };
}
async function staffLogin(name, email) {
  await loginAs(name, email);
  const enroll = await request(server).post("/api/v1/auth/mfa/totp/enroll").set(auth(name));
  const verify = await request(server).post("/api/v1/auth/mfa/totp/verify")
    .set(auth(name)).send({ code: totpCode(enroll.body.secret) });
  assert.equal(verify.status, 201, JSON.stringify(verify.body));
}

before(async () => {
  idp = await startMockIdp(IDP);
  const made = createDb();
  db = made.db;
  await runMigrations(made.pg);
  ids = await seed(db);
  app = await createApp(db);
  server = app.getHttpServer();
  await staffLogin("t1", "t1@school.example");
  await staffLogin("t2", "t2@school.example");
  await staffLogin("admin", "admin@school.example");
  await staffLogin("root", "root@school.example");
  await loginAs("s1", "s1@school.example");
  await loginAs("p1", "p1@school.example");
});
after(async () => { await app.close(); idp.close(); });

/* ── messaging ── */
let threadId;
test("teacher opens thread for own student; other teacher refused", async () => {
  const ok = await request(server).post("/api/v1/threads").set(auth("t1"))
    .send({ student_user_id: ids.s1, subject: "Sola's progress" });
  assert.equal(ok.status, 201, JSON.stringify(ok.body));
  threadId = ok.body.id;
  const denied = await request(server).post("/api/v1/threads").set(auth("t2"))
    .send({ student_user_id: ids.s1, subject: "hi" });
  assert.equal(denied.status, 403);
  assert.equal(denied.body.code, "outside_section_scope");
});

test("parent reads thread/messages; writes refused; student sees nothing", async () => {
  const post = await request(server).post(`/api/v1/threads/${threadId}/messages`).set(auth("t1"))
    .send({ body_text: "Sola did great this week." });
  assert.equal(post.status, 201, JSON.stringify(post.body));

  const list = await request(server).get("/api/v1/threads").set(auth("p1"));
  assert.equal(list.status, 200);
  assert.equal(list.body.data.length, 1);
  assert.equal(list.body.data[0].studentName, "Sola Student");

  const detail = await request(server).get(`/api/v1/threads/${threadId}`).set(auth("p1"));
  assert.equal(detail.status, 200);
  assert.equal(detail.body.messages.length, 1);

  const parentWrite = await request(server).post(`/api/v1/threads/${threadId}/messages`).set(auth("p1"))
    .send({ body_text: "thanks!" });
  assert.equal(parentWrite.status, 403);
  assert.equal(parentWrite.body.code, "parent_read_only");

  const studentView = await request(server).get("/api/v1/threads").set(auth("s1"));
  assert.equal(studentView.status, 200);
  assert.equal(studentView.body.data.length, 0);

  const outsider = await request(server).get(`/api/v1/threads/${threadId}`).set(auth("t2"));
  assert.equal(outsider.status, 404); // RLS-invisible ⇒ not found
});

test("teacher message enqueues guardian notification", async () => {
  const inbox = await request(server).get("/api/v1/notifications").set(auth("p1"));
  assert.equal(inbox.status, 200);
  assert.ok(inbox.body.data.some((n) => n.kind === "message_received"), JSON.stringify(inbox.body.data.map((n) => n.kind)));
});

/* ── notification hooks ── */
const date = new Date().toISOString().slice(0, 10);
test("absence transition enqueues guardian email+push", async () => {
  const save = await request(server).post(`/api/v1/sections/${ids.sec1}/attendance`).set(auth("t1"))
    .set("idempotency-key", crypto.randomUUID())
    .send({ date, records: [{ student_user_id: ids.s1, status: "absent" }] });
  assert.equal(save.status, 201, JSON.stringify(save.body));
  const inbox = await request(server).get("/api/v1/notifications").set(auth("p1"));
  const alerts = inbox.body.data.filter((n) => n.kind === "absence_recorded");
  assert.equal(alerts.length, 2); // email + push
  assert.deepEqual(alerts.map((a) => a.channel).sort(), ["email", "push"]);
});

test("re-saving same absence does NOT re-alert; grade release notifies student+parent", async () => {
  const again = await request(server).post(`/api/v1/sections/${ids.sec1}/attendance`).set(auth("t1"))
    .set("idempotency-key", crypto.randomUUID())
    .send({ date, records: [{ student_user_id: ids.s1, status: "absent" }] });
  assert.equal(again.status, 201);
  const inbox = await request(server).get("/api/v1/notifications").set(auth("p1"));
  assert.equal(inbox.body.data.filter((n) => n.kind === "absence_recorded").length, 2, "no duplicate alert");

  const grade = await request(server).post(`/api/v1/sections/${ids.sec1}/grades/bulk`).set(auth("t1"))
    .set("idempotency-key", crypto.randomUUID())
    .send({ items: [{ student_user_id: ids.s1, source_type: "custom", label: "5.3 Quiz", points: "90", max_points: "100" }] });
  assert.equal(grade.status, 201);
  const rel = await request(server).post(`/api/v1/sections/${ids.sec1}/grades/release`).set(auth("t1"));
  assert.equal(rel.status, 201);
  for (const who of ["s1", "p1"]) {
    const n = await request(server).get("/api/v1/notifications").set(auth(who));
    assert.ok(n.body.data.some((x) => x.kind === "grade_released"), `${who} got grade_released`);
  }
});

/* ── worker ── */
test("worker drains outbox: emails delivered, push sinks, failures recorded", async () => {
  // give s1 a push subscription + a push notification to exercise the sink
  await request(server).post("/api/v1/notifications/push").set(auth("s1"))
    .send({ endpoint: "https://push.example/abc", keys: { p256dh: "pk", auth: "ak" } });
  await withActor(db, SERVICE, (tx) => tx.insert(notifications).values({
    recipientUserId: ids.s1, channel: "push", kind: "absence_recorded", payload: { test: true },
  }));

  const sentMails = [];
  const mailer = { sendMail: async (opts) => { sentMails.push(opts); return {}; } };
  const r1 = await processQueue(db, { mailer, pushSinkFile: PUSH_SINK });
  assert.ok(r1.processed >= 5, `processed ${r1.processed}`);
  assert.ok(sentMails.length >= 4, `emails ${sentMails.length}`);
  assert.ok(sentMails.some((m) => /Absence recorded/.test(m.subject)));
  assert.ok(existsSync(PUSH_SINK), "push sink file written");
  assert.match(readFileSync(PUSH_SINK, "utf8"), /push\.example/);

  // p1's push row fails honestly (no subscription) and is marked failed
  const failed = await withActor(db, SERVICE, (tx) =>
    tx.select().from(notifications).where(eq(notifications.status, "failed")));
  assert.ok(failed.length >= 1 && failed.every((f) => /no push subscription/.test(f.lastError)));

  const r2 = await processQueue(db, { mailer, pushSinkFile: PUSH_SINK });
  assert.equal(r2.processed, 0, "queue empty after drain");
});

test("daily digest: one per recipient per day, idempotent", async () => {
  const first = await runDigest(db);
  assert.ok(first.created >= 2, `created ${first.created}`); // p1 + s1 had events today
  const second = await runDigest(db);
  assert.equal(second.created, 0, "idempotent per day");
  const inbox = await request(server).get("/api/v1/notifications").set(auth("p1"));
  const digest = inbox.body.data.find((n) => n.kind === "daily_digest");
  assert.ok(digest && digest.payload.date === date, "digest payload dated today");
  assert.ok(digest.payload.absences >= 1 && digest.payload.gradesReleased >= 1);
});

/* ── report cards ── */
test("report cards: generate (admin), read (self/guardian), denied (others)", async () => {
  const gen = await request(server).post("/api/v1/report-cards/generate").set(auth("root")).send({});
  assert.equal(gen.status, 201, JSON.stringify(gen.body));
  assert.ok(gen.body.generated >= 1);

  const mine = await request(server).get(`/api/v1/students/${ids.s1}/report-card`).set(auth("s1"));
  assert.equal(mine.status, 200);
  const snap = mine.body.data[0].snapshot;
  assert.ok(snap.sections.some((s) => s.course === "MTH-101"), "MTH-101 in snapshot");

  const parent = await request(server).get(`/api/v1/students/${ids.s1}/report-card`).set(auth("p1"));
  assert.equal(parent.status, 200);

  const teacher = await request(server).get(`/api/v1/students/${ids.s1}/report-card`).set(auth("t2"));
  assert.equal(teacher.status, 403);
});

/* ── directory writes ── */
test("admin creates user; duplicate email refused; new user can log in", async () => {
  const created = await request(server).post("/api/v1/users").set(auth("admin"))
    .send({ email: "new.kid@school.example", display_name: "New Kid", password: "Passw0rd!", roles: ["student"] });
  assert.equal(created.status, 201, JSON.stringify(created.body));
  const dupe = await request(server).post("/api/v1/users").set(auth("admin"))
    .send({ email: "NEW.kid@school.example", display_name: "X", password: "Passw0rd!", roles: ["student"] });
  assert.equal(dupe.status, 409);
  assert.equal(dupe.body.code, "email_taken");
  await loginAs("newkid", "new.kid@school.example"); // login works ⇒ password + role persisted
  const sess = await request(server).get("/api/v1/auth/session").set(auth("newkid"));
  assert.deepEqual(sess.body.roles, ["student"]);
});

test("roles:write is super_admin-only; grant + revoke audited", async () => {
  const denied = await request(server).post(`/api/v1/users/${ids.s1}/roles`).set(auth("admin"))
    .send({ role_code: "teacher_assistant" });
  assert.equal(denied.status, 403);
  assert.equal(denied.body.code, "missing_capability");

  const granted = await request(server).post(`/api/v1/users/${ids.s1}/roles`).set(auth("root"))
    .send({ role_code: "student" }); // already held → conflict path
  assert.equal(granted.status, 409);
  const g2 = await request(server).post(`/api/v1/users/${ids.s1}/roles`).set(auth("root"))
    .send({ role_code: "teacher_assistant" });
  assert.equal(g2.status, 201, JSON.stringify(g2.body));
  const revoked = await request(server).delete(`/api/v1/users/${ids.s1}/roles/teacher_assistant`).set(auth("root"));
  assert.equal(revoked.status, 200);
  assert.equal(revoked.body.revoked, 1);
});

/* ── academics writes ── */
test("section create, enrollment, duplicate refusal, admission lookup", async () => {
  const sec = await request(server).post("/api/v1/sections").set(auth("admin"))
    .send({ course_code: "BIO-101", course_title: "Biology", name: "BIO-101 A", term_id: ids.term });
  assert.equal(sec.status, 201, JSON.stringify(sec.body));
  const dupe = await request(server).post("/api/v1/sections").set(auth("admin"))
    .send({ course_code: "BIO-101", course_title: "Biology", name: "BIO-101 A", term_id: ids.term });
  assert.equal(dupe.status, 409);

  const en = await request(server).post(`/api/v1/sections/${sec.body.id}/enrollments`).set(auth("admin"))
    .send({ student_user_id: ids.s1 });
  assert.equal(en.status, 201);
  const en2 = await request(server).post(`/api/v1/sections/${sec.body.id}/enrollments`).set(auth("admin"))
    .send({ student_user_id: ids.s1 });
  assert.equal(en2.status, 409);
  assert.equal(en2.body.code, "already_enrolled");

  const lookup = await request(server).get("/api/v1/students-lookup?admission_no=stu-0001").set(auth("admin"));
  assert.equal(lookup.status, 200);
  assert.equal(lookup.body.displayName, "Sola Student");

  const teacherDenied = await request(server).post("/api/v1/sections").set(auth("t1"))
    .send({ course_code: "X-1", course_title: "x", name: "x", term_id: ids.term });
  assert.equal(teacherDenied.status, 403); // teachers lack academics:write
});

/* ── push subscription lifecycle + parent guard ── */
test("push subscribe/unsubscribe; parent blocked by read-only guard", async () => {
  const sub = await request(server).post("/api/v1/notifications/push").set(auth("s1"))
    .send({ endpoint: "https://push.example/s1-device", keys: { p256dh: "pk", auth: "ak" } });
  assert.equal(sub.status, 201);
  const un = await request(server).post(`/api/v1/notifications/push/${sub.body.id}/unsubscribe`).set(auth("s1"));
  assert.equal(un.status, 201);
  assert.equal(un.body.removed, 1);

  const parentSub = await request(server).post("/api/v1/notifications/push").set(auth("p1"))
    .send({ endpoint: "https://push.example/p1" });
  assert.equal(parentSub.status, 403);
  assert.equal(parentSub.body.code, "parent_read_only");
});

/* ── SSO (OIDC authorization-code via mock IdP) ── */
async function ssoFlow(provider, email) {
  const start = await request(server).get(`/api/v1/auth/sso/${provider}/start`);
  assert.equal(start.status, 302);
  const authUrl = new URL(start.headers.location);
  assert.equal(authUrl.searchParams.get("client_id"), `${provider}-client`);
  assert.ok(authUrl.searchParams.get("state"));
  // walk the IdP: auto-approve → callback URL with code+state
  const approved = await fetch(`${authUrl.toString()}&mock_email=${encodeURIComponent(email)}`, { redirect: "manual" });
  assert.equal(approved.status, 302);
  const cb = new URL(approved.headers.get("location"));
  return request(server).get(`/api/v1/auth/sso/${provider}/callback`)
    .query({ code: cb.searchParams.get("code"), state: cb.searchParams.get("state") });
}

test("SSO: JIT-provisions unknown user, session + cookie set", async () => {
  const cb = await ssoFlow("entra", "fresh.face@example.com");
  assert.equal(cb.status, 302, JSON.stringify(cb.body ?? {}));
  assert.equal(cb.headers.location, "http://127.0.0.1:3000/"); // student ⇒ no MFA redirect
  const sid = cookiesOf(cb).sid;
  assert.ok(sid, "session cookie set on web origin via BFF path");
  const sess = await request(server).get("/api/v1/auth/session").set({ Cookie: `sid=${sid}` });
  assert.equal(sess.status, 200);
  assert.equal(sess.body.email, "fresh.face@example.com");
  assert.deepEqual(sess.body.roles, ["student"]);
});

test("SSO: links existing directory user by email; staff still MFA-gated", async () => {
  const cb = await ssoFlow("entra", "t2@school.example");
  assert.equal(cb.status, 302);
  assert.equal(cb.headers.location, "http://127.0.0.1:3000/mfa"); // teacher ⇒ MFA gate
  const sid = cookiesOf(cb).sid;
  const sess = await request(server).get("/api/v1/auth/session").set({ Cookie: `sid=${sid}` });
  assert.equal(sess.body.email, "t2@school.example");
  assert.deepEqual(sess.body.roles, ["teacher"]);
  // and the MFA gate actually blocks data access pre-verification
  const blocked = await request(server).get("/api/v1/sections").set({ Cookie: `sid=${sid}` });
  assert.equal(blocked.status, 403);
  assert.equal(blocked.body.code, "mfa_required");
});

test("SSO: unprovisioned identity refused when JIT disabled", async () => {
  const cb = await ssoFlow("google", "stranger@example.com");
  assert.equal(cb.status, 403);
  assert.equal(cb.body.code, "sso_user_not_provisioned");
});

test("SSO: tampered state rejected", async () => {
  const start = await request(server).get("/api/v1/auth/sso/entra/start");
  const state = new URL(start.headers.location).searchParams.get("state");
  const [b64] = state.split(".");
  const cb = await request(server).get("/api/v1/auth/sso/entra/callback")
    .query({ code: Buffer.from("x@y.z").toString("base64url"), state: `${b64}.deadbeef` });
  assert.equal(cb.status, 302);
  assert.match(cb.headers.location, /sso_error=state/);
});
