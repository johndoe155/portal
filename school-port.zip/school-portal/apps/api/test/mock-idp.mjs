/**
 * Minimal OIDC mock IdP for tests: /authorize auto-approves (identity chosen
 * via mock_email query param), /token returns an HS256 id_token.
 * Real IdPs (Entra/Google) use RS256+JWKS — the API supports both paths.
 */
import { createServer } from "node:http";
import { SignJWT } from "jose";

const HMAC_SECRET = "mock-secret";

export function startMockIdp(port) {
  const server = createServer(async (req, res) => {
    const url = new URL(req.url, `http://127.0.0.1:${port}`);
    try {
      if (url.pathname === "/authorize" && req.method === "GET") {
        const redirectUri = url.searchParams.get("redirect_uri");
        const state = url.searchParams.get("state");
        const email = url.searchParams.get("mock_email") ?? "someone@example.com";
        if (!redirectUri || !state) { res.writeHead(400).end("missing params"); return; }
        const code = Buffer.from(email).toString("base64url");
        const sep = redirectUri.includes("?") ? "&" : "?";
        res.writeHead(302, { location: `${redirectUri}${sep}code=${code}&state=${encodeURIComponent(state)}` }).end();
        return;
      }
      if (url.pathname === "/token" && req.method === "POST") {
        const chunks = [];
        for await (const c of req) chunks.push(c);
        const form = new URLSearchParams(Buffer.concat(chunks).toString());
        const email = Buffer.from(form.get("code") ?? "", "base64url").toString();
        if (!email) { res.writeHead(400).end("bad code"); return; }
        const idToken = await new SignJWT({ email, name: `Mock ${email.split("@")[0]}` })
          .setProtectedHeader({ alg: "HS256" })
          .setSubject(`mock-${email}`)
          .setIssuer(`http://127.0.0.1:${port}`)
          .setAudience(form.get("client_id") ?? "mock-client")
          .setIssuedAt()
          .setExpirationTime("10m")
          .sign(new TextEncoder().encode(HMAC_SECRET));
        res.writeHead(200, { "content-type": "application/json" })
          .end(JSON.stringify({ access_token: "mock-at", token_type: "Bearer", id_token: idToken }));
        return;
      }
      res.writeHead(404).end();
    } catch (err) {
      res.writeHead(500).end(String(err));
    }
  });
  return new Promise((resolve) => server.listen(port, "127.0.0.1", () => resolve(server)));
}
