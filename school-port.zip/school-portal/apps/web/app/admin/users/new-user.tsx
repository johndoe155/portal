"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/client";

const ROLES = ["student", "parent", "teacher", "teacher_assistant", "registrar", "counselor", "school_admin", "auditor"];

export default function NewUser() {
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("student");
  const [err, setErr] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr(""); setInfo("");
    try {
      await api("/users", {
        method: "POST",
        body: JSON.stringify({ email, display_name: name, password, roles: [role] }),
      });
      setInfo(`Created ${email} (${role}). They can sign in with the temporary password.`);
      setEmail(""); setName(""); setPassword("");
      router.refresh();
    } catch (e: any) {
      setErr(e?.code === "email_taken" ? "That email already exists." : e?.message ?? "Could not create user");
    }
    setBusy(false);
  }

  if (!open) return <button className="btn" onClick={() => setOpen(true)}>+ New user</button>;
  return (
    <form className="card" onSubmit={submit}>
      <h2 style={{ marginTop: 0 }}>New user</h2>
      {err && <div className="alert err" role="alert">{err}</div>}
      {info && <div className="alert ok" role="status">{info}</div>}
      <div className="grid cols2">
        <div><label htmlFor="nu-name">Display name</label>
          <input id="nu-name" value={name} onChange={(e) => setName(e.target.value)} required maxLength={120} /></div>
        <div><label htmlFor="nu-email">Email</label>
          <input id="nu-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></div>
        <div><label htmlFor="nu-pass">Temporary password</label>
          <input id="nu-pass" type="password" value={password} onChange={(e) => setPassword(e.target.value)}
            required minLength={8} autoComplete="new-password" /></div>
        <div><label htmlFor="nu-role">Role</label>
          <select id="nu-role" value={role} onChange={(e) => setRole(e.target.value)}>
            {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
          </select></div>
      </div>
      <div className="row" style={{ marginTop: 12 }}>
        <button className="btn" disabled={busy}>Create</button>
        <button type="button" className="btn ghost" onClick={() => setOpen(false)}>Cancel</button>
      </div>
    </form>
  );
}
