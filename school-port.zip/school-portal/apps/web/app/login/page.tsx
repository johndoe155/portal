import { redirect } from "next/navigation";
import { checkSession, ROLE_HOME } from "@/lib/session";
import LoginForm from "./login-form";

export default async function LoginPage() {
  const check = await checkSession();
  if (check.kind === "authed") redirect(ROLE_HOME[check.session.activeRole] ?? "/student");
  if (check.kind === "mfa") redirect("/mfa");
  return (
    <div className="container" style={{ maxWidth: 420, paddingTop: 48 }}>
      <h1>School Portal</h1>
      <p className="muted">Sign in with your school account. Staff and admin accounts require two-factor authentication.</p>
      <LoginForm />
      <div className="card muted" style={{ marginTop: 18 }}>
        <strong>Demo seeds</strong>
        <div>admin@school.example · t1@school.example · t2@school.example · s1@school.example · p1@school.example</div>
        <div>Password: Passw0rd! &nbsp;(staff/admin must enrol TOTP at first MFA screen)</div>
      </div>
    </div>
  );
}
